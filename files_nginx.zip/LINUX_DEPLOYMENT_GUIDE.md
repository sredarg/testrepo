# Linux Production Deployment Guide
## Atoll Pipeline Dashboard — Company-Wide Access

---

## 🏗️ Architecture Overview

```
                    Your Company Network
                         │
        ┌────────────────┼────────────────┐
        │                │                │
   Office A          Office B         Office C
   Browser           Browser          Browser
        │                │                │
        └────────────────┴────────────────┘
                         │
                    Port 80 (HTTP)
                    Port 443 (HTTPS)
                         │
                  ┌──────▼──────┐
                  │    NGINX    │  ← Handles all external traffic
                  │  (port 80)  │    Serves static files
                  └──────┬──────┘    Proxies /api → Node
                         │
              ┌──────────┴──────────┐
              │                     │
    ┌─────────▼──────┐   ┌─────────▼──────┐
    │  React Build   │   │  Express API   │
    │  /var/www/     │   │  (port 3001)   │
    │  atoll-dash/   │   │  PM2 managed   │
    └────────────────┘   └───────┬────────┘
                                 │
                        ┌────────▼────────┐
                        │   PostgreSQL    │
                        │  radio schema   │
                        └─────────────────┘
```

---

## 📋 Prerequisites

Before starting, make sure you have:

| Requirement | Check |
|-------------|-------|
| Linux server (Ubuntu 20.04+ or CentOS 7+) | `cat /etc/os-release` |
| Root / sudo access | `sudo whoami` |
| PostgreSQL running with radio.aws_instances | `psql -U postgres` |
| Internet access (to download Node.js, NGINX) | `curl google.com` |
| Port 80 accessible from company network | Firewall rules |

---

## 🚀 Deployment Steps

### Method 1: Automated (Recommended)

Edit the top of `deploy.sh` with your values:
```bash
SERVER_NAME="10.0.1.50"           # your server IP or domain name
DB_HOST="localhost"
DB_NAME="your_database"
DB_USER="atoll_user"
DB_PASSWORD="your_strong_password"
```

Then run:
```bash
chmod +x deploy/deploy.sh
sudo ./deploy/deploy.sh
```

That's it! The script handles everything below automatically.

---

### Method 2: Manual Step-by-Step

Follow these steps if you prefer to control each stage.

#### Step 1 — Install Node.js 18

**Ubuntu/Debian:**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo bash -
sudo apt-get install -y nodejs
node --version    # should show v18.x
```

**CentOS/RHEL:**
```bash
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs
node --version
```

---

#### Step 2 — Install NGINX

**Ubuntu/Debian:**
```bash
sudo apt-get install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx
```

**CentOS/RHEL:**
```bash
sudo yum install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx
```

Verify: open `http://your-server-ip` in a browser — you should see the NGINX welcome page.

---

#### Step 3 — Install PM2

PM2 keeps the Node.js API server running and restarts it if it crashes.

```bash
sudo npm install -g pm2
pm2 --version    # should show 5.x or higher
```

---

#### Step 4 — Set Up the Database

```bash
# Connect to PostgreSQL
psql -h localhost -U postgres -d your_database

# Run the production DB setup script
\i deploy/db/db_setup_production.sql
```

This creates:
- `radio.pipeline_errors` table
- A dedicated `atoll_user` database user
- Optimized indexes

---

#### Step 5 — Create a System User

Create a non-privileged user to run the app (security best practice):

```bash
sudo useradd --system --no-create-home --shell /usr/sbin/nologin atoll
```

---

#### Step 6 — Deploy Application Files

```bash
# Create directories
sudo mkdir -p /opt/atoll-dashboard /var/www/atoll-dashboard /var/log/atoll-dashboard

# Copy project files
sudo cp -r server src public package.json tsconfig.json /opt/atoll-dashboard/

# Install backend dependencies
cd /opt/atoll-dashboard/server
sudo npm install --production

# Build the React frontend
cd /opt/atoll-dashboard
sudo npm install
sudo REACT_APP_API_URL=/api npm run build

# Deploy build to web root
sudo cp -r /opt/atoll-dashboard/build/. /var/www/atoll-dashboard/
sudo chown -R www-data:www-data /var/www/atoll-dashboard
```

---

#### Step 7 — Configure Environment Variables

```bash
sudo nano /opt/atoll-dashboard/server/.env
```

Add your values:
```env
NODE_ENV=production
PORT=3001
DB_HOST=localhost
DB_PORT=5432
DB_NAME=your_database
DB_USER=atoll_user
DB_PASSWORD=your_strong_password
ALLOWED_ORIGINS=http://your-server-ip
```

Lock down the file (contains DB password):
```bash
sudo chmod 600 /opt/atoll-dashboard/server/.env
sudo chown atoll:atoll /opt/atoll-dashboard/server/.env
```

---

#### Step 8 — Configure NGINX

```bash
sudo cp deploy/nginx/atoll-dashboard.conf /etc/nginx/sites-available/atoll-dashboard
```

Edit the `server_name` line:
```bash
sudo nano /etc/nginx/sites-available/atoll-dashboard
# Change: server_name your-server-ip-or-domain.com;
# To:     server_name 10.0.1.50;    (your actual IP)
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/atoll-dashboard /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default   # remove default page
sudo nginx -t                                  # test config
sudo systemctl reload nginx
```

---

#### Step 9 — Start the API Server

```bash
# Copy PM2 config
sudo cp deploy/pm2/ecosystem.config.js /opt/atoll-dashboard/

# Start as 'atoll' user
sudo -u atoll pm2 start /opt/atoll-dashboard/ecosystem.config.js

# Save the process list
sudo -u atoll pm2 save

# Enable PM2 to start on boot
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u atoll --hp /home/atoll
# Copy and run the command it outputs
```

---

#### Step 10 — Configure Firewall

```bash
chmod +x deploy/firewall.sh
sudo ./deploy/firewall.sh
```

Or manually:
```bash
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw deny 3001/tcp    # block direct API access — NGINX handles it
sudo ufw enable
```

---

## ✅ Verify Deployment

```bash
chmod +x deploy/healthcheck.sh
./deploy/healthcheck.sh

# Or check from another machine:
./deploy/healthcheck.sh http://your-server-ip
```

Expected output:
```
✅ PASS  NGINX is running
✅ PASS  PM2 'atoll-api' process is running
✅ PASS  Dashboard UI
✅ PASS  Health endpoint
✅ PASS  Summary API
✅ PASS  Servers API
✅ PASS  Timeline API
✅ PASS  Stages API
✅ PASS  Recent errors API
✅ PASS  PostgreSQL connection OK
✅ PASS  pipeline_errors table has N rows
```

---

## 📁 Final Folder Structure on Server

```
/
├── opt/atoll-dashboard/         ← Application code
│   ├── server/
│   │   ├── index.js
│   │   ├── .env                 ← DB credentials (chmod 600)
│   │   └── node_modules/
│   ├── src/
│   ├── build/                   ← React production build
│   ├── package.json
│   └── ecosystem.config.js      ← PM2 config
│
├── var/
│   ├── www/atoll-dashboard/     ← Files served by NGINX
│   └── log/atoll-dashboard/     ← App logs
│
└── etc/
    └── nginx/
        ├── sites-available/atoll-dashboard   ← NGINX config
        └── sites-enabled/atoll-dashboard     ← Symlink to above
```

---

## 🔄 Day-to-Day Operations

### Check if everything is running
```bash
pm2 status
sudo systemctl status nginx
```

### View live logs
```bash
pm2 logs atoll-api                       # API server logs
sudo tail -f /var/log/nginx/atoll-dashboard-error.log   # NGINX errors
```

### Restart after code change
```bash
sudo ./deploy/update.sh
```

### Restart just the API server
```bash
pm2 restart atoll-api
```

### Restart NGINX
```bash
sudo systemctl reload nginx
```

---

## 🔐 Adding HTTPS (Recommended for company use)

Once DNS is set up pointing to your server:

```bash
# Ubuntu/Debian
sudo apt-get install -y certbot python3-certbot-nginx

# Get certificate (replace with your domain)
sudo certbot --nginx -d dashboard.yourcompany.com

# Certbot will automatically update the NGINX config
# Certificate auto-renews every 90 days
```

Then update `server/.env`:
```env
ALLOWED_ORIGINS=https://dashboard.yourcompany.com
```

Reload:
```bash
pm2 restart atoll-api
sudo systemctl reload nginx
```

---

## 📊 Accessing the Dashboard

| Who | URL |
|-----|-----|
| Same network | `http://your-server-ip` |
| With domain | `http://dashboard.yourcompany.com` |
| With HTTPS   | `https://dashboard.yourcompany.com` |

Share the URL with your team — anyone on the company network can open it in a browser. No software installation required for users.

---

## 🐛 Troubleshooting

### "502 Bad Gateway" in browser
→ NGINX can't reach the API server
```bash
pm2 status          # Is atoll-api running?
pm2 restart atoll-api
```

### Dashboard loads but shows "Failed to fetch"
→ API returning errors
```bash
pm2 logs atoll-api --lines 50     # Check error messages
# Usually a database connection problem — check .env credentials
```

### "Connection refused" when opening the URL
→ NGINX is down or firewall blocking port 80
```bash
sudo systemctl status nginx
sudo systemctl start nginx
sudo ufw allow 80/tcp
```

### Database errors in API logs
→ Check .env credentials match your PostgreSQL setup
```bash
# Test the DB connection directly
psql -h localhost -U atoll_user -d your_database
# If this fails, fix credentials in /opt/atoll-dashboard/server/.env
pm2 restart atoll-api
```

### PM2 doesn't restart on reboot
```bash
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u atoll --hp /home/atoll
# Run the command it outputs
sudo -u atoll pm2 save
```

---

## 🗓️ Scheduled Maintenance (Cron)

Add cleanup job to run at 2am daily:

```bash
sudo crontab -e

# Add this line:
0 2 * * * /opt/atoll-dashboard/deploy/cron/cleanup.sh >> /var/log/atoll-dashboard/cleanup.log 2>&1
```

This automatically:
- Deletes errors older than 30 days
- Vacuums the database weekly
- Cleans old log files

---

## 📈 Performance Notes

With 300 servers and company-wide access:

| Metric | Expected |
|--------|----------|
| Concurrent users | 50+ users simultaneously |
| API response time | < 100ms |
| Dashboard load time | < 2 seconds |
| Auto-refresh impact | Minimal (lightweight queries) |

The setup (NGINX + PM2 cluster mode) will handle your load comfortably.
