-- ============================================
-- SQL Schema for Atoll Pipeline Error Tracking
-- ============================================

-- 1. CREATE ERROR TRACKING TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS radio.pipeline_errors (
    error_id SERIAL PRIMARY KEY,
    instance_id VARCHAR(50) NOT NULL,
    error_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    error_type VARCHAR(100),
    error_message TEXT,
    pipeline_stage VARCHAR(100),
    severity VARCHAR(20) CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    resolved BOOLEAN DEFAULT FALSE,
    resolved_timestamp TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key to existing aws_instances table
    CONSTRAINT fk_instance 
        FOREIGN KEY (instance_id) 
        REFERENCES radio.aws_instances(instance_id)
        ON DELETE CASCADE
);

-- Create indexes for better query performance
CREATE INDEX idx_pipeline_errors_instance_id ON radio.pipeline_errors(instance_id);
CREATE INDEX idx_pipeline_errors_timestamp ON radio.pipeline_errors(error_timestamp DESC);
CREATE INDEX idx_pipeline_errors_resolved ON radio.pipeline_errors(resolved);
CREATE INDEX idx_pipeline_errors_severity ON radio.pipeline_errors(severity);


-- ============================================
-- 2. DASHBOARD SQL QUERIES
-- ============================================

-- Query 1: Real-time Error Summary (for top cards/KPIs)
-- ============================================
SELECT 
    COUNT(*) as total_errors,
    COUNT(DISTINCT instance_id) as affected_servers,
    COUNT(CASE WHEN resolved = FALSE THEN 1 END) as active_errors,
    COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) as critical_errors
FROM radio.pipeline_errors
WHERE error_timestamp >= NOW() - INTERVAL '24 hours';


-- Query 2: Errors by Server (main dashboard table)
-- ============================================
SELECT 
    ai.instance_id,
    ai.ipaddress,
    ai.status as server_status,
    COUNT(pe.error_id) as error_count,
    COUNT(CASE WHEN pe.resolved = FALSE THEN 1 END) as active_errors,
    MAX(pe.error_timestamp) as last_error_time,
    MAX(CASE WHEN pe.severity = 'CRITICAL' THEN 1 ELSE 0 END) as has_critical_error
FROM radio.aws_instances ai
LEFT JOIN radio.pipeline_errors pe 
    ON ai.instance_id = pe.instance_id 
    AND pe.error_timestamp >= NOW() - INTERVAL '24 hours'
GROUP BY ai.instance_id, ai.ipaddress, ai.status
ORDER BY error_count DESC, has_critical_error DESC;


-- Query 3: Error Timeline (for charts - errors over time)
-- ============================================
SELECT 
    DATE_TRUNC('hour', error_timestamp) as hour,
    COUNT(*) as error_count,
    COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) as critical_count
FROM radio.pipeline_errors
WHERE error_timestamp >= NOW() - INTERVAL '24 hours'
GROUP BY DATE_TRUNC('hour', error_timestamp)
ORDER BY hour;


-- Query 4: Errors by Type/Stage (for pie/bar charts)
-- ============================================
SELECT 
    pipeline_stage,
    error_type,
    COUNT(*) as count,
    COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) as critical_count
FROM radio.pipeline_errors
WHERE error_timestamp >= NOW() - INTERVAL '24 hours'
GROUP BY pipeline_stage, error_type
ORDER BY count DESC
LIMIT 10;


-- Query 5: Recent Errors Detail View
-- ============================================
SELECT 
    pe.error_id,
    pe.instance_id,
    ai.ipaddress,
    pe.error_timestamp,
    pe.error_type,
    pe.error_message,
    pe.pipeline_stage,
    pe.severity,
    pe.resolved
FROM radio.pipeline_errors pe
JOIN radio.aws_instances ai ON pe.instance_id = ai.instance_id
WHERE pe.error_timestamp >= NOW() - INTERVAL '24 hours'
ORDER BY pe.error_timestamp DESC
LIMIT 100;


-- Query 6: Server Health Overview (servers with no errors vs with errors)
-- ============================================
SELECT 
    CASE 
        WHEN error_count = 0 THEN 'Healthy'
        WHEN error_count BETWEEN 1 AND 5 THEN 'Warning'
        WHEN error_count > 5 THEN 'Critical'
    END as health_status,
    COUNT(*) as server_count
FROM (
    SELECT 
        ai.instance_id,
        COUNT(pe.error_id) as error_count
    FROM radio.aws_instances ai
    LEFT JOIN radio.pipeline_errors pe 
        ON ai.instance_id = pe.instance_id 
        AND pe.error_timestamp >= NOW() - INTERVAL '24 hours'
    GROUP BY ai.instance_id
) server_errors
GROUP BY health_status;


-- ============================================
-- 3. SAMPLE DATA INSERT (for testing)
-- ============================================

-- Example: Insert sample error
INSERT INTO radio.pipeline_errors 
    (instance_id, error_type, error_message, pipeline_stage, severity)
VALUES 
    ('i-0123456789abcdef0', 'TimeoutError', 'Pipeline execution timeout after 300s', 'Coverage Generation', 'HIGH');

-- Example: Bulk insert for testing (adjust instance_ids to match your data)
-- INSERT INTO radio.pipeline_errors (instance_id, error_type, error_message, pipeline_stage, severity)
-- SELECT 
--     instance_id,
--     'ConfigError',
--     'Missing configuration parameter',
--     'Initialization',
--     'MEDIUM'
-- FROM radio.aws_instances
-- LIMIT 5;
