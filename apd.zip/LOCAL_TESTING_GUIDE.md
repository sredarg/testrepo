# Local Testing Guide - Complete Walkthrough

## Step 0: Prerequisites

### Check if you have Node.js installed:
```bash
node --version
# Should show v16 or higher (e.g., v18.17.0)

npm --version
# Should show v8 or higher
```

**Don't have Node.js?** Download from: https://nodejs.org/
- Download the LTS (Long Term Support) version
- Run the installer
- Restart your terminal/command prompt

### Check if you have PostgreSQL:
```bash
psql --version
# Should show PostgreSQL version (e.g., PostgreSQL 14.x)
```

**Don't have PostgreSQL?**
- Windows: Download from https://www.postgresql.org/download/windows/
- Mac: `brew install postgresql` or download from postgresql.org
- Linux: `sudo apt-get install postgresql` (Ubuntu/Debian)

---

## Step 1: Extract the Project Files

1. Download all the files from this conversation
2. Extract to a folder, for example:
   - Windows: `C:\Projects\atoll-dashboard\`
   - Mac/Linux: `~/Projects/atoll-dashboard/`

3. Your folder structure should look like:
```
atoll-dashboard/
├── src/
├── server/
├── public/
├── package.json
├── database_schema.sql
└── README.md
```

---

## Step 2: Set Up the Database

### Option A: Using Existing PostgreSQL Server

If you already have a PostgreSQL server (like for radio.aws_instances):

1. **Connect to your database:**
```bash
# Windows Command Prompt
psql -h localhost -U your_username -d your_database

# Mac/Linux Terminal
psql -h localhost -U your_username -d your_database
```

2. **Run the schema file:**
```bash
# From the project directory
psql -h localhost -U your_username -d your_database -f database_schema.sql
```

3. **Verify tables were created:**
```sql
-- Inside psql
\dt radio.*

-- You should see:
-- radio.aws_instances (existing)
-- radio.pipeline_errors (new)
```

### Option B: Create a Fresh Local Database for Testing

If you want to test in isolation:

1. **Create a new database:**
```bash
# Connect to PostgreSQL
psql -U postgres

# Create test database
CREATE DATABASE atoll_test;

# Connect to it
\c atoll_test

# Create the radio schema
CREATE SCHEMA radio;
```

2. **Create a mock aws_instances table:**
```sql
CREATE TABLE radio.aws_instances (
    instance_id VARCHAR(50) PRIMARY KEY,
    ipaddress VARCHAR(15),
    status VARCHAR(20)
);

-- Insert some test servers
INSERT INTO radio.aws_instances (instance_id, ipaddress, status) VALUES
    ('i-test001', '10.0.1.1', 'running'),
    ('i-test002', '10.0.1.2', 'running'),
    ('i-test003', '10.0.1.3', 'running'),
    ('i-test004', '10.0.1.4', 'stopped'),
    ('i-test005', '10.0.1.5', 'running');
```

3. **Run the schema file:**
```bash
# Exit psql (\q) then run:
psql -U postgres -d atoll_test -f database_schema.sql
```

4. **Insert test error data:**
```sql
-- Connect back to database
psql -U postgres -d atoll_test

-- Insert test errors
INSERT INTO radio.pipeline_errors 
    (instance_id, error_type, error_message, pipeline_stage, severity)
VALUES 
    ('i-test001', 'TimeoutError', 'Pipeline execution timeout after 300s', 'Coverage Generation', 'HIGH'),
    ('i-test001', 'ConfigError', 'Missing required parameter: output_path', 'Initialization', 'MEDIUM'),
    ('i-test002', 'MemoryError', 'Out of memory during processing', 'Data Processing', 'CRITICAL'),
    ('i-test003', 'NetworkError', 'Failed to connect to remote server', 'Data Upload', 'HIGH'),
    ('i-test002', 'ValidationError', 'Invalid input data format', 'Validation', 'LOW'),
    ('i-test001', 'RuntimeError', 'Unexpected exception in worker thread', 'Execution', 'HIGH'),
    ('i-test004', 'ConfigError', 'Server configuration mismatch', 'Initialization', 'CRITICAL'),
    ('i-test005', 'TimeoutError', 'Database query timeout', 'Data Processing', 'MEDIUM');
```

---

## Step 3: Set Up the Backend Server

1. **Navigate to the server directory:**
```bash
cd server
```

2. **Install dependencies:**
```bash
npm install
```

This will install:
- express (web framework)
- pg (PostgreSQL client)
- cors (cross-origin requests)
- dotenv (environment variables)

3. **Create environment file:**
```bash
# Windows
copy .env.example .env

# Mac/Linux
cp .env.example .env
```

4. **Edit the .env file with your database credentials:**

Open `server/.env` in a text editor and update:

```env
PORT=3001

# Update these with YOUR database info:
DB_HOST=localhost
DB_PORT=5432
DB_NAME=atoll_test          # or your actual database name
DB_USER=postgres            # or your PostgreSQL username
DB_PASSWORD=yourpassword    # YOUR PostgreSQL password
```

5. **Test the database connection:**
```bash
# Start the server
npm start
```

You should see:
```
Database connected successfully
Server running on port 3001
Health check: http://localhost:3001/health
```

6. **Test the health endpoint:**

Open a browser and go to: `http://localhost:3001/health`

You should see:
```json
{
  "success": true,
  "message": "API is running",
  "timestamp": "2024-02-14T..."
}
```

7. **Test an API endpoint:**

Go to: `http://localhost:3001/api/summary`

You should see your error data:
```json
{
  "success": true,
  "data": {
    "total_errors": 8,
    "affected_servers": 4,
    "active_errors": 8,
    "critical_errors": 2
  }
}
```

**🎉 If you see this, your backend is working!**

Leave this terminal running (don't close it).

---

## Step 4: Set Up the Frontend

1. **Open a NEW terminal/command prompt**

2. **Navigate to the project root:**
```bash
cd C:\Projects\atoll-dashboard\    # Windows
# OR
cd ~/Projects/atoll-dashboard/     # Mac/Linux
```

3. **Install dependencies:**
```bash
npm install
```

This will install:
- react
- react-dom
- typescript
- react-scripts (build tools)

This might take 2-3 minutes.

4. **Create environment file:**
```bash
# Windows
copy .env.example .env

# Mac/Linux
cp .env.example .env
```

5. **Verify the .env file:**

Open `.env` and make sure it says:
```env
REACT_APP_API_URL=http://localhost:3001/api
```

6. **Start the development server:**
```bash
npm start
```

This will:
- Compile TypeScript to JavaScript
- Start a development server
- Automatically open your browser to `http://localhost:3000`

You should see:
```
Compiled successfully!

You can now view atoll-pipeline-dashboard in the browser.

  Local:            http://localhost:3000
  On Your Network:  http://192.168.x.x:3000
```

**🎉 The dashboard should automatically open in your browser!**

---

## Step 5: Verify Everything Works

### Check the Dashboard

You should see:

1. **Top Cards with numbers:**
   - Total Errors: 8
   - Affected Servers: 4
   - Active Errors: 8
   - Critical Errors: 2

2. **Server Table:**
   - Should show i-test001, i-test002, etc.
   - With their IP addresses
   - Error counts per server

3. **Timeline Chart:**
   - Bar chart showing errors over time

4. **Stage Breakdown:**
   - Showing which pipeline stages have errors

5. **Recent Errors:**
   - List of your test errors
   - Click any error to expand details

### Test Interactive Features

1. **Filter the table:**
   - Type "test001" in the filter box
   - Should show only i-test001

2. **Sort the table:**
   - Click "Total Errors" column header
   - Should sort by error count

3. **Expand an error:**
   - Click any error in the Recent Errors section
   - Should show full error message
   - See "Mark as Resolved" button

4. **Refresh:**
   - Click the "🔄 Refresh" button
   - Should reload data

5. **Auto-refresh:**
   - Check the "Auto-refresh" checkbox
   - Every 30 seconds it should update

---

## Step 6: Add More Test Data

### Using the API (Recommended)

Open a third terminal and run:

```bash
# Windows PowerShell or Mac/Linux Terminal
curl -X POST http://localhost:3001/api/errors \
  -H "Content-Type: application/json" \
  -d "{\"instance_id\": \"i-test001\", \"error_type\": \"NewError\", \"error_message\": \"This is a new test error\", \"pipeline_stage\": \"Testing\", \"severity\": \"HIGH\"}"
```

**Windows Command Prompt** (if curl doesn't work):
Use PowerShell instead, or install curl for Windows.

**Alternative - Use a browser extension:**
- Install "Postman" or "REST Client" extension
- Send POST to `http://localhost:3001/api/errors`
- Body:
```json
{
  "instance_id": "i-test001",
  "error_type": "NewError",
  "error_message": "This is a new test error",
  "pipeline_stage": "Testing",
  "severity": "HIGH"
}
```

### Using SQL

```sql
psql -U postgres -d atoll_test

INSERT INTO radio.pipeline_errors 
    (instance_id, error_type, error_message, pipeline_stage, severity)
VALUES 
    ('i-test001', 'BrandNewError', 'Just added this!', 'Testing', 'CRITICAL');
```

### Verify it appears

- Click "Refresh" button in the dashboard
- Should see the new error appear!

---

## 🐛 Troubleshooting

### Issue: "npm: command not found"
**Solution:** Node.js isn't installed or not in PATH
- Download and install Node.js from nodejs.org
- Restart your terminal

### Issue: "psql: command not found"
**Solution:** PostgreSQL not installed or not in PATH
- Install PostgreSQL
- Add to PATH (usually done automatically)

### Issue: Backend shows "Database connection error"
**Solution:** Check your .env file
```bash
# Verify credentials
psql -h localhost -U postgres -d atoll_test
# If this works, copy these exact values to .env
```

### Issue: Frontend shows "Failed to fetch dashboard data"
**Solution:** Backend not running
- Check terminal where you ran `npm start` in server/
- Should say "Server running on port 3001"
- Test: http://localhost:3001/health

### Issue: Dashboard is blank/white screen
**Solution:** Check browser console
- Press F12 to open Developer Tools
- Look at Console tab for errors
- Look at Network tab to see if API calls are failing

### Issue: "Port 3000 is already in use"
**Solution:** Another app is using port 3000
```bash
# Use a different port
PORT=3002 npm start
# Then update .env to REACT_APP_API_URL=http://localhost:3002/api
```

### Issue: TypeScript errors during build
**Solution:** Delete node_modules and reinstall
```bash
rm -rf node_modules package-lock.json  # Mac/Linux
# OR
rmdir /s node_modules & del package-lock.json  # Windows

npm install
```

---

## 📊 What to Expect

### Startup Time
- Backend: 2-3 seconds
- Frontend: 30-60 seconds (first time compile)
- Dashboard load: 1-2 seconds

### Performance
- Should feel instant when clicking/filtering
- Auto-refresh: every 30 seconds
- API response: < 100ms for all endpoints

### Resource Usage
- Backend: ~50MB RAM
- Frontend dev server: ~200MB RAM
- PostgreSQL: ~100MB RAM

---

## ✅ Success Checklist

- [ ] Node.js installed (node --version works)
- [ ] PostgreSQL installed (psql --version works)
- [ ] Database created and schema loaded
- [ ] Test data inserted (8+ errors)
- [ ] Backend server running (localhost:3001/health responds)
- [ ] Frontend server running (localhost:3000 opens)
- [ ] Dashboard shows test data
- [ ] Can filter and sort table
- [ ] Can expand error details
- [ ] Can add new errors via API
- [ ] Refresh button works

**All checked? You're ready to deploy!** 🚀

---

## 🎯 Next Steps After Testing

1. **Connect to your real database:**
   - Update server/.env with production DB credentials
   - Ensure radio.aws_instances table exists
   - Run database_schema.sql

2. **Set up error collection:**
   - Use PowerShell/Python scripts from README
   - Configure Atoll pipeline to log errors

3. **Deploy to production:**
   - Follow README.md deployment section
   - Choose Windows/IIS, Linux/Nginx, or Docker

4. **Customize:**
   - Adjust auto-refresh interval
   - Change colors in CSS
   - Add more severity levels

---

## 💡 Quick Commands Reference

### Start Everything (after initial setup)

**Terminal 1 - Backend:**
```bash
cd server
npm start
```

**Terminal 2 - Frontend:**
```bash
cd ..  # back to project root
npm start
```

### Stop Everything
- Press `Ctrl+C` in both terminals

### Reset Database
```bash
psql -U postgres -d atoll_test -c "DROP TABLE radio.pipeline_errors; DROP TABLE radio.aws_instances;"
psql -U postgres -d atoll_test -f database_schema.sql
```

### View Logs
- Backend: Check terminal where server is running
- Frontend: Browser Developer Tools (F12) → Console
- Database: `psql -U postgres -d atoll_test`

---

## 📞 Still Having Issues?

1. Check browser console (F12)
2. Check server terminal for errors
3. Verify database connection with psql
4. Make sure both servers are running
5. Check .env files have correct values
6. Review the full error message

**Most common issue:** Database credentials in .env don't match your actual PostgreSQL setup!
