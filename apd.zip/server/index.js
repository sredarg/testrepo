// server/index.js  (Production-hardened version)
const express = require('express');
const cors    = require('cors');
const { Pool } = require('pg');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// PostgreSQL connection pool
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'your_database',
  user: process.env.DB_USER || 'your_user',
  password: process.env.DB_PASSWORD || 'your_password',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Middleware
app.use(cors());
app.use(express.json());

// Test database connection
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('Database connection error:', err);
  } else {
    console.log('Database connected successfully');
  }
});

// Helper function for error responses
const handleError = (res, error, message = 'Server error') => {
  console.error(message, error);
  res.status(500).json({
    success: false,
    message,
    error: error.message
  });
};

// API Routes

// GET /api/summary - Error summary statistics
app.get('/api/summary', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        COUNT(*) as total_errors,
        COUNT(DISTINCT instance_id) as affected_servers,
        COUNT(CASE WHEN resolved = FALSE THEN 1 END) as active_errors,
        COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) as critical_errors
      FROM radio.pipeline_errors
      WHERE error_timestamp >= NOW() - INTERVAL '24 hours'
    `);

    res.json({
      success: true,
      data: {
        total_errors: parseInt(result.rows[0].total_errors),
        affected_servers: parseInt(result.rows[0].affected_servers),
        active_errors: parseInt(result.rows[0].active_errors),
        critical_errors: parseInt(result.rows[0].critical_errors)
      }
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch summary');
  }
});

// GET /api/servers - Errors by server
app.get('/api/servers', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        ai.instance_id,
        ai.ipaddress,
        ai.status as server_status,
        COUNT(pe.error_id) as error_count,
        COUNT(CASE WHEN pe.resolved = FALSE THEN 1 END) as active_errors,
        MAX(pe.error_timestamp) as last_error_time,
        MAX(CASE WHEN pe.severity = 'CRITICAL' THEN 1 ELSE 0 END) as has_critical_error
      FROM radio.aws_instances ai
      LEFT JOIN radio.pipeline_errors pe 
        ON ai.instance_id = pe.instance_id 
        AND pe.error_timestamp >= NOW() - INTERVAL '24 hours'
      GROUP BY ai.instance_id, ai.ipaddress, ai.status
      ORDER BY error_count DESC, has_critical_error DESC
    `);

    res.json({
      success: true,
      data: result.rows.map(row => ({
        ...row,
        error_count: parseInt(row.error_count),
        active_errors: parseInt(row.active_errors),
        has_critical_error: parseInt(row.has_critical_error)
      }))
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch server errors');
  }
});

// GET /api/timeline - Error timeline
app.get('/api/timeline', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        DATE_TRUNC('hour', error_timestamp) as hour,
        COUNT(*) as error_count,
        COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) as critical_count
      FROM radio.pipeline_errors
      WHERE error_timestamp >= NOW() - INTERVAL '24 hours'
      GROUP BY DATE_TRUNC('hour', error_timestamp)
      ORDER BY hour
    `);

    res.json({
      success: true,
      data: result.rows.map(row => ({
        ...row,
        error_count: parseInt(row.error_count),
        critical_count: parseInt(row.critical_count)
      }))
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch timeline');
  }
});

// GET /api/stages - Errors by pipeline stage
app.get('/api/stages', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        pipeline_stage,
        error_type,
        COUNT(*) as count,
        COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) as critical_count
      FROM radio.pipeline_errors
      WHERE error_timestamp >= NOW() - INTERVAL '24 hours'
      GROUP BY pipeline_stage, error_type
      ORDER BY count DESC
      LIMIT 10
    `);

    res.json({
      success: true,
      data: result.rows.map(row => ({
        ...row,
        count: parseInt(row.count),
        critical_count: parseInt(row.critical_count)
      }))
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch stage data');
  }
});

// GET /api/recent - Recent errors
app.get('/api/recent', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        pe.error_id,
        pe.instance_id,
        ai.ipaddress,
        pe.error_timestamp,
        pe.error_type,
        pe.error_message,
        pe.pipeline_stage,
        pe.severity,
        pe.resolved
      FROM radio.pipeline_errors pe
      JOIN radio.aws_instances ai ON pe.instance_id = ai.instance_id
      WHERE pe.error_timestamp >= NOW() - INTERVAL '24 hours'
      ORDER BY pe.error_timestamp DESC
      LIMIT 100
    `);

    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch recent errors');
  }
});

// PATCH /api/errors/:id/resolve - Mark error as resolved
app.patch('/api/errors/:id/resolve', async (req, res) => {
  const { id } = req.params;
  
  try {
    const result = await pool.query(`
      UPDATE radio.pipeline_errors
      SET resolved = TRUE, resolved_timestamp = NOW()
      WHERE error_id = $1
      RETURNING *
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Error not found'
      });
    }

    res.json({
      success: true,
      data: result.rows[0],
      message: 'Error marked as resolved'
    });
  } catch (error) {
    handleError(res, error, 'Failed to resolve error');
  }
});

// POST /api/errors - Create new error (for testing or external logging)
app.post('/api/errors', async (req, res) => {
  const { instance_id, error_type, error_message, pipeline_stage, severity } = req.body;

  if (!instance_id || !error_type || !error_message || !pipeline_stage) {
    return res.status(400).json({
      success: false,
      message: 'Missing required fields'
    });
  }

  try {
    const result = await pool.query(`
      INSERT INTO radio.pipeline_errors 
        (instance_id, error_type, error_message, pipeline_stage, severity)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `, [instance_id, error_type, error_message, pipeline_stage, severity || 'MEDIUM']);

    res.status(201).json({
      success: true,
      data: result.rows[0],
      message: 'Error logged successfully'
    });
  } catch (error) {
    handleError(res, error, 'Failed to create error');
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'API is running',
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found'
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    success: false,
    message: 'Internal server error'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  pool.end(() => {
    console.log('Database pool closed');
    process.exit(0);
  });
});
