// deploy/pm2/ecosystem.config.js
// PM2 process manager configuration
// Usage:
//   pm2 start ecosystem.config.js
//   pm2 save
//   pm2 startup   (to auto-start on reboot)

module.exports = {
  apps: [
    {
      name: 'atoll-api',
      script: '/apps/opt/jpuv/apps/atoll-dashboard/server/index.js',

      // ── Process settings ──────────────────────────────────────────────
      instances: 2,           // Run 2 processes for reliability (or 'max' for all CPU cores)
      exec_mode: 'cluster',   // Load balance between instances

      // ── Environment ───────────────────────────────────────────────────
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
      },

      // ── Auto-restart settings ─────────────────────────────────────────
      watch: false,           // Don't watch for file changes in production
      autorestart: true,      // Restart if process crashes
      max_restarts: 10,       // Max restarts before giving up
      restart_delay: 5000,    // Wait 5s between restarts (ms)
      min_uptime: '10s',      // Must stay up 10s to count as successful start

      // ── Memory limits ─────────────────────────────────────────────────
      max_memory_restart: '500M',   // Restart if memory exceeds 500MB

      // ── Logging ───────────────────────────────────────────────────────
      log_file:   '/var/log/atoll-dashboard/combined.log',
      out_file:   '/var/log/atoll-dashboard/out.log',
      error_file: '/var/log/atoll-dashboard/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      merge_logs: true,

      // ── Graceful shutdown ─────────────────────────────────────────────
      kill_timeout: 5000,     // Give 5s for graceful shutdown
      wait_ready: true,       // Wait for app to signal ready
    },
  ],
};
