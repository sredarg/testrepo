#!/bin/bash
# =============================================================================
# ssl_renew.sh — Renew SSL Certificate from Commercial CA
# CentOS / RHEL / Rocky Linux + Apache HTTPD
#
# Run this ~30 days before your certificate expires.
# Your private key stays the same — only the cert is renewed.
#
# Usage:
#   chmod +x ssl_renew.sh
#   sudo ./ssl_renew.sh
# =============================================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC}    $1"; }
success() { echo -e "${GREEN}[  OK  ]${NC}  $1"; }
warn()    { echo -e "${YELLOW}[ WARN ]${NC}  $1"; }
error()   { echo -e "${RED}[ ERR  ]${NC}  $1"; exit 1; }

# ══ EDIT THESE ══════════════════════════════════════════════════════════════
DOMAIN="dashboard.yourcompany.com"
SSL_DIR="/etc/pki/tls"
CERT_DIR="$SSL_DIR/certs"
KEY_DIR="$SSL_DIR/private"
CSR_DIR="/root/ssl-csr"
# ═══════════════════════════════════════════════════════════════════════════

[[ $EUID -ne 0 ]] && error "Run as root: sudo ./ssl_renew.sh"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   SSL Certificate Renewal — Commercial CA                ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

KEY_FILE="$KEY_DIR/$DOMAIN.key"
CERT_FILE="$CERT_DIR/$DOMAIN.crt"
CHAIN_FILE="$CERT_DIR/$DOMAIN-chain.crt"

# ── Show current cert expiry ───────────────────────────────────────────────
echo "Current certificate status:"
if [[ -f "$CERT_FILE" ]]; then
  openssl x509 -in "$CERT_FILE" -noout -dates
  echo ""
  EXPIRY=$(openssl x509 -in "$CERT_FILE" -noout -enddate | cut -d= -f2)
  EXPIRY_EPOCH=$(date -d "$EXPIRY" +%s)
  NOW_EPOCH=$(date +%s)
  DAYS_LEFT=$(( (EXPIRY_EPOCH - NOW_EPOCH) / 86400 ))

  if [[ $DAYS_LEFT -gt 30 ]]; then
    warn "Certificate doesn't expire for $DAYS_LEFT days."
    warn "You don't need to renew yet — but continuing anyway."
  elif [[ $DAYS_LEFT -gt 0 ]]; then
    warn "Certificate expires in $DAYS_LEFT days — good time to renew!"
  else
    error "Certificate has ALREADY EXPIRED! Renew immediately."
  fi
else
  warn "No existing certificate found at $CERT_FILE"
fi

echo ""
info "For renewal, you reuse your EXISTING private key."
info "This means your CSR will have the same details as before."
echo ""

# ── Generate a new CSR using the EXISTING private key ─────────────────────
CSR_FILE="$CSR_DIR/${DOMAIN}_renewal_$(date +%Y%m%d).csr"
CSR_CONF="$CSR_DIR/$DOMAIN.cnf"

mkdir -p "$CSR_DIR"

if [[ ! -f "$CSR_CONF" ]]; then
  warn "Original CSR config not found. Enter your details:"
  read -p "  Domain [$DOMAIN]: " input; DOMAIN=${input:-$DOMAIN}
  read -p "  Country (2 letters): " COUNTRY
  read -p "  State (full name):   " STATE
  read -p "  City:                " CITY
  read -p "  Company name:        " COMPANY
  read -p "  Department:          " DEPT

  cat > "$CSR_CONF" << CONF
[req]
default_bits       = 2048
prompt             = no
default_md         = sha256
distinguished_name = dn
req_extensions     = req_ext

[dn]
C  = $COUNTRY
ST = $STATE
L  = $CITY
O  = $COMPANY
OU = $DEPT
CN = $DOMAIN

[req_ext]
subjectAltName = @alt_names

[alt_names]
DNS.1 = $DOMAIN
DNS.2 = www.$DOMAIN
CONF
fi

# Generate renewal CSR using existing private key (no new key needed)
openssl req -new \
  -key  "$KEY_FILE" \
  -out  "$CSR_FILE" \
  -config "$CSR_CONF"

cp "$CSR_FILE" "/root/${DOMAIN}_renewal.csr"
chmod 644 "/root/${DOMAIN}_renewal.csr"
success "Renewal CSR created: /root/${DOMAIN}_renewal.csr"

echo ""
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │  Submit this CSR to your CA to get a new certificate │"
echo "  │                                                     │"
echo "  │  cat /root/${DOMAIN}_renewal.csr                    │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""
read -p "  Press ENTER once you have the new certificate files from your CA..."

# ── Install the new certificate files ─────────────────────────────────────
echo ""
read -p "  Path to new certificate (.crt): " NEW_CERT
read -p "  Path to new CA bundle:          " NEW_CHAIN

# Back up old certificate before replacing
BACKUP_DATE=$(date +%Y%m%d%H%M%S)
[[ -f "$CERT_FILE"  ]] && cp "$CERT_FILE"  "${CERT_FILE}.bak.$BACKUP_DATE"
[[ -f "$CHAIN_FILE" ]] && cp "$CHAIN_FILE" "${CHAIN_FILE}.bak.$BACKUP_DATE"
success "Old certificates backed up"

if [[ -f "$NEW_CERT" ]]; then
  cp "$NEW_CERT"  "$CERT_FILE"
  chmod 644 "$CERT_FILE"
  success "New certificate installed"
else
  error "Certificate file not found: $NEW_CERT"
fi

if [[ -f "$NEW_CHAIN" ]]; then
  cp "$NEW_CHAIN" "$CHAIN_FILE"
  chmod 644 "$CHAIN_FILE"
  success "New CA bundle installed"
else
  warn "CA bundle not found — using existing one"
fi

# ── Verify new cert matches key ────────────────────────────────────────────
CERT_MOD=$(openssl x509 -noout -modulus -in "$CERT_FILE" | md5sum)
KEY_MOD=$(openssl rsa  -noout -modulus -in "$KEY_FILE"  | md5sum)
if [[ "$CERT_MOD" == "$KEY_MOD" ]]; then
  success "New certificate and private key MATCH"
else
  error "Certificate and key DO NOT match — wrong cert file?"
fi

# ── Show new expiry date ───────────────────────────────────────────────────
echo ""
echo "New certificate validity:"
openssl x509 -in "$CERT_FILE" -noout -dates

# ── Reload Apache ──────────────────────────────────────────────────────────
apachectl configtest 2>&1 | grep -q "Syntax OK" || error "Apache config error — check before reloading"
systemctl reload httpd
success "Apache reloaded with new certificate"

echo ""
success "Certificate renewal complete!"
echo ""
echo "  New certificate installed for: $DOMAIN"
echo "  Set your next renewal reminder 30 days before the expiry above."
echo ""
