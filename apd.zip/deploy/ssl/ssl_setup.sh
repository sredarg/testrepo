#!/bin/bash
# =============================================================================
# ssl_setup.sh — Commercial CA SSL Certificate Setup
# CentOS / RHEL / Rocky Linux + Apache HTTPD
#
# This script handles the FULL process:
#   Step 1: Generate a Private Key
#   Step 2: Generate a CSR (Certificate Signing Request)
#   Step 3: (Manual) Submit CSR to DigiCert/GlobalSign
#   Step 4: Install the signed certificate files
#   Step 5: Configure Apache for HTTPS
#   Step 6: Test and reload Apache
#
# Usage:
#   chmod +x ssl_setup.sh
#   sudo ./ssl_setup.sh
# =============================================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC}    $1"; }
success() { echo -e "${GREEN}[  OK  ]${NC}  $1"; }
warn()    { echo -e "${YELLOW}[ WARN ]${NC}  $1"; }
error()   { echo -e "${RED}[ ERR  ]${NC}  $1"; exit 1; }
step()    { echo -e "\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; \
            echo -e "${CYAN}  $1${NC}"; \
            echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

# ══ EDIT THESE BEFORE RUNNING ══════════════════════════════════════════════
DOMAIN="dashboard.yourcompany.com"     # your actual domain name
COMPANY="Your Company Name"            # legal company name
DEPT="IT Operations"                   # department
CITY="Your City"
STATE="Your State"                     # full state name, no abbreviation
COUNTRY="US"                           # 2-letter country code

# Where cert files will live on the server
SSL_DIR="/etc/pki/tls"                 # standard RHEL/CentOS path
CERT_DIR="$SSL_DIR/certs"
KEY_DIR="$SSL_DIR/private"
CSR_DIR="/root/ssl-csr"                # working directory for CSR files
# ═══════════════════════════════════════════════════════════════════════════

[[ $EUID -ne 0 ]] && error "Run as root: sudo ./ssl_setup.sh"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   SSL Certificate Setup — Commercial CA                  ║"
echo "║   CentOS / RHEL / Rocky Linux + Apache HTTPD             ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  Domain  : $DOMAIN"
echo "  Company : $COMPANY"
echo "  Cert dir: $CERT_DIR"
echo ""

# ── Prerequisites ──────────────────────────────────────────────────────────
step "Checking prerequisites..."
command -v openssl &>/dev/null || { yum install -y openssl; success "openssl installed"; }
command -v httpd   &>/dev/null || error "Apache HTTPD is not installed"
openssl version
success "Prerequisites OK"

# ── Create working directory ───────────────────────────────────────────────
mkdir -p "$CSR_DIR"
chmod 700 "$CSR_DIR"

# =============================================================================
# STEP 1 — Generate Private Key
# =============================================================================
step "STEP 1 of 6 — Generating Private Key"

KEY_FILE="$KEY_DIR/$DOMAIN.key"

if [[ -f "$KEY_FILE" ]]; then
  warn "Key file already exists: $KEY_FILE"
  warn "Delete it first if you want to regenerate."
else
  # 2048-bit RSA is standard; use 4096 for maximum security
  openssl genrsa -out "$KEY_FILE" 2048
  chmod 600 "$KEY_FILE"       # only root can read the private key
  chown root:root "$KEY_FILE"
  success "Private key created: $KEY_FILE"
fi

echo ""
echo "  Private key details:"
openssl rsa -in "$KEY_FILE" -noout -text 2>/dev/null | grep -E "Private-Key|RSA"

# =============================================================================
# STEP 2 — Generate CSR (Certificate Signing Request)
# =============================================================================
step "STEP 2 of 6 — Generating CSR"

CSR_FILE="$CSR_DIR/$DOMAIN.csr"
CSR_CONF="$CSR_DIR/$DOMAIN.cnf"

# Write OpenSSL config for the CSR
cat > "$CSR_CONF" << OPENSSLCONF
[req]
default_bits       = 2048
prompt             = no
default_md         = sha256
distinguished_name = dn
req_extensions     = req_ext

[dn]
C                  = $COUNTRY
ST                 = $STATE
L                  = $CITY
O                  = $COMPANY
OU                 = $DEPT
CN                 = $DOMAIN

[req_ext]
subjectAltName     = @alt_names

[alt_names]
DNS.1              = $DOMAIN
DNS.2              = www.$DOMAIN
OPENSSLCONF

# Generate the CSR
openssl req -new \
  -key "$KEY_FILE" \
  -out "$CSR_FILE" \
  -config "$CSR_CONF"

success "CSR created: $CSR_FILE"

echo ""
echo "  CSR details (verify these are correct):"
openssl req -in "$CSR_FILE" -noout -text | grep -A 10 "Subject:"

# Copy CSR to a readable location for easy transfer
cp "$CSR_FILE" "/root/$DOMAIN.csr"
chmod 644 "/root/$DOMAIN.csr"

echo ""
success "CSR also copied to: /root/$DOMAIN.csr"

# =============================================================================
# STEP 3 — Submit CSR to CA (Manual Step)
# =============================================================================
step "STEP 3 of 6 — Submit CSR to Your CA (MANUAL STEP)"

echo ""
echo "  You need to submit the CSR to DigiCert/GlobalSign."
echo "  Your CSR file is at: /root/$DOMAIN.csr"
echo ""
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │  Run this to display the CSR content to copy/paste: │"
echo "  │                                                     │"
echo "  │  cat /root/$DOMAIN.csr                              │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""
echo "  The CSR looks like this:"
echo "  -----BEGIN CERTIFICATE REQUEST-----"
echo "  MIIByjCCATMCAQAwgakxCzAJBgNVBAYTAlVTMRYw..."
echo "  -----END CERTIFICATE REQUEST-----"
echo ""
echo "  Steps at your CA portal:"
echo "    1. Log in to DigiCert/GlobalSign portal"
echo "    2. Order a new SSL certificate"
echo "    3. Paste the entire CSR content (including BEGIN/END lines)"
echo "    4. Choose server type: Apache"
echo "    5. Complete domain validation (email or DNS)"
echo "    6. Download the signed certificate files when ready"
echo ""
warn "The CA will send you 2-3 files. You need:"
echo "    - your_domain.crt  (your certificate)"
echo "    - ca_bundle.crt    (intermediate/chain certificates)"
echo "      (DigiCert calls this 'DigiCertCA.crt' or 'chain.crt')"
echo "      (GlobalSign calls this 'intermediate.crt' or 'bundle.crt')"
echo ""

read -p "  Press ENTER when you have received the certificate files from your CA..."

# =============================================================================
# STEP 4 — Install Certificate Files
# =============================================================================
step "STEP 4 of 6 — Installing Certificate Files"

echo ""
echo "  Where are your certificate files? Enter the full paths."
echo "  (Press ENTER to skip if you will place them manually)"
echo ""

read -p "  Path to your certificate (.crt file): " USER_CERT
read -p "  Path to CA bundle/chain file:          " USER_CHAIN

CERT_FILE="$CERT_DIR/$DOMAIN.crt"
CHAIN_FILE="$CERT_DIR/$DOMAIN-chain.crt"

if [[ -f "$USER_CERT" ]]; then
  cp "$USER_CERT"  "$CERT_FILE"
  chmod 644 "$CERT_FILE"
  success "Certificate installed: $CERT_FILE"
else
  warn "Certificate file not found. You'll need to place it manually:"
  warn "  cp your_cert.crt $CERT_FILE"
fi

if [[ -f "$USER_CHAIN" ]]; then
  cp "$USER_CHAIN" "$CHAIN_FILE"
  chmod 644 "$CHAIN_FILE"
  success "CA bundle installed: $CHAIN_FILE"
else
  warn "CA bundle not found. You'll need to place it manually:"
  warn "  cp ca_bundle.crt $CHAIN_FILE"
fi

# =============================================================================
# STEP 5 — Configure Apache for HTTPS
# =============================================================================
step "STEP 5 of 6 — Configuring Apache HTTPD for HTTPS"

# Install mod_ssl
rpm -q mod_ssl &>/dev/null || yum install -y mod_ssl
success "mod_ssl installed"

# Back up existing config
VHOST_CONF="/etc/httpd/conf.d/atoll-dashboard.conf"
if [[ -f "$VHOST_CONF" ]]; then
  cp "$VHOST_CONF" "${VHOST_CONF}.bak.$(date +%Y%m%d%H%M%S)"
  success "Backed up existing Apache config"
fi

# Write the full Apache config with both HTTP redirect and HTTPS
cat > "$VHOST_CONF" << APACHECONF
# =============================================================
# Atoll Pipeline Dashboard — Apache HTTPS Config
# Generated by ssl_setup.sh on $(date)
# =============================================================

# ── Redirect all HTTP traffic to HTTPS ───────────────────────
<VirtualHost *:80>
    ServerName $DOMAIN
    RewriteEngine On
    RewriteRule ^(.*)$ https://%{HTTP_HOST}\$1 [R=301,L]
</VirtualHost>

# ── HTTPS Virtual Host ────────────────────────────────────────
<VirtualHost *:443>
    ServerName   $DOMAIN
    DocumentRoot /var/www/atoll-dashboard

    # ── SSL Configuration ─────────────────────────────────────
    SSLEngine on

    SSLCertificateFile    $CERT_FILE
    SSLCertificateKeyFile $KEY_FILE
    SSLCertificateChainFile $CHAIN_FILE

    # ── Modern SSL settings (TLS 1.2 and 1.3 only) ───────────
    SSLProtocol           -all +TLSv1.2 +TLSv1.3
    SSLCipherSuite        ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384
    SSLHonorCipherOrder   off
    SSLSessionTickets     off

    # ── Logging ───────────────────────────────────────────────
    ErrorLog  /var/log/httpd/atoll-dashboard-error.log
    CustomLog /var/log/httpd/atoll-dashboard-access.log combined

    # ── Frontend (React build) ────────────────────────────────
    <Directory /var/www/atoll-dashboard>
        Options -Indexes -FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # React Router — all non-file URLs → index.html
    <IfModule mod_rewrite.c>
        RewriteEngine On
        RewriteBase /
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteCond %{REQUEST_URI} !^/api
        RewriteCond %{REQUEST_URI} !^/health
        RewriteRule ^ /index.html [L]
    </IfModule>

    # ── API Proxy → Node.js ───────────────────────────────────
    <IfModule mod_proxy.c>
        ProxyRequests     Off
        ProxyPreserveHost On
        ProxyPass        /api    http://127.0.0.1:3001/api
        ProxyPassReverse /api    http://127.0.0.1:3001/api
        ProxyPass        /health http://127.0.0.1:3001/health
        ProxyPassReverse /health http://127.0.0.1:3001/health
        RequestHeader set X-Real-IP        "%{REMOTE_ADDR}e"
        RequestHeader set X-Forwarded-For  "%{REMOTE_ADDR}e"
        RequestHeader set X-Forwarded-Proto "https"
    </IfModule>

    # ── Security headers ──────────────────────────────────────
    <IfModule mod_headers.c>
        Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
        Header always set X-Frame-Options            "SAMEORIGIN"
        Header always set X-Content-Type-Options     "nosniff"
        Header always set X-XSS-Protection           "1; mode=block"
        Header always set Referrer-Policy            "strict-origin-when-cross-origin"
        Header unset Server
    </IfModule>

    # ── Cache static assets ───────────────────────────────────
    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType application/javascript "access plus 1 year"
        ExpiresByType text/css               "access plus 1 year"
        ExpiresByType image/png              "access plus 1 year"
    </IfModule>

    # ── Gzip compression ──────────────────────────────────────
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css
        AddOutputFilterByType DEFLATE application/javascript application/json
    </IfModule>

    # ── Block hidden files ────────────────────────────────────
    <FilesMatch "^\\.">
        Require all denied
    </FilesMatch>

</VirtualHost>
APACHECONF

success "Apache HTTPS config written"

# Also update the API server's .env to reflect HTTPS
ENV_FILE="/opt/atoll-dashboard/server/.env"
if [[ -f "$ENV_FILE" ]]; then
  sed -i "s|ALLOWED_ORIGINS=http://|ALLOWED_ORIGINS=https://|g" "$ENV_FILE"
  success "Updated ALLOWED_ORIGINS in .env to https://"
fi

# Open port 443 in firewall
if command -v firewall-cmd &>/dev/null; then
  firewall-cmd --permanent --add-service=https
  firewall-cmd --reload
  success "Port 443 opened in firewalld"
fi

# =============================================================================
# STEP 6 — Test and Reload Apache
# =============================================================================
step "STEP 6 of 6 — Testing and Reloading Apache"

# Test config before applying
echo ""
info "Testing Apache config syntax..."
if apachectl configtest 2>&1 | grep -q "Syntax OK"; then
  success "Apache config syntax is valid"
else
  echo ""
  apachectl configtest
  error "Apache config has errors — see above. Fix before reloading."
fi

# Verify cert and key match (common mistake — mismatched files)
echo ""
info "Verifying certificate and key match..."
if [[ -f "$CERT_FILE" && -f "$KEY_FILE" ]]; then
  CERT_MOD=$(openssl x509 -noout -modulus -in "$CERT_FILE" 2>/dev/null | md5sum)
  KEY_MOD=$(openssl rsa  -noout -modulus -in "$KEY_FILE"  2>/dev/null | md5sum)
  if [[ "$CERT_MOD" == "$KEY_MOD" ]]; then
    success "Certificate and private key MATCH"
  else
    error "Certificate and key DO NOT match! You may have the wrong cert file."
  fi
else
  warn "Cannot verify match — cert files not yet installed"
fi

# Reload Apache
systemctl reload httpd
success "Apache reloaded"

# Restart PM2 API server so it picks up new ALLOWED_ORIGINS
if command -v pm2 &>/dev/null; then
  su -s /bin/bash atoll -c "pm2 restart atoll-api" 2>/dev/null || true
  success "API server restarted"
fi

# =============================================================================
# Done
# =============================================================================
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║              ✅  SSL Setup Complete!                     ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo -e "  Dashboard  : ${GREEN}https://$DOMAIN${NC}"
echo -e "  Health     : ${GREEN}https://$DOMAIN/health${NC}"
echo ""
echo "  Certificate files:"
echo "    Certificate : $CERT_FILE"
echo "    Private Key : $KEY_FILE"
echo "    CA Bundle   : $CHAIN_FILE"
echo "    CSR (keep!) : /root/$DOMAIN.csr"
echo ""
warn "Important reminders:"
echo "  1. Keep the private key ($KEY_FILE) safe — never share it"
echo "  2. Note your certificate expiry date (usually 1 year):"
openssl x509 -in "$CERT_FILE" -noout -dates 2>/dev/null | sed 's/^/     /' || echo "     (install cert first)"
echo "  3. Set a calendar reminder 30 days before expiry to renew"
echo "  4. Run ./ssl_verify.sh any time to check SSL health"
echo ""
