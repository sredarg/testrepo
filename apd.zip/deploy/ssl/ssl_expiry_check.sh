#!/bin/bash
# =============================================================================
# ssl_expiry_check.sh — Daily cron job to warn before certificate expires
#
# Add to crontab:
#   sudo crontab -e
#   0 8 * * * /opt/atoll-dashboard/deploy/ssl/ssl_expiry_check.sh
# =============================================================================

DOMAIN="dashboard.yourcompany.com"
CERT_FILE="/etc/pki/tls/certs/$DOMAIN.crt"
ALERT_EMAIL="your-team@yourcompany.com"   # <-- change this
WARN_DAYS=30                               # warn when this many days remain

[[ -f "$CERT_FILE" ]] || exit 0

EXPIRY=$(openssl x509 -in "$CERT_FILE" -noout -enddate | cut -d= -f2)
EXPIRY_EPOCH=$(date -d "$EXPIRY" +%s)
NOW_EPOCH=$(date +%s)
DAYS_LEFT=$(( (EXPIRY_EPOCH - NOW_EPOCH) / 86400 ))

if [[ $DAYS_LEFT -le $WARN_DAYS ]]; then
  SUBJECT="⚠️ SSL Certificate Expiring in $DAYS_LEFT Days — $DOMAIN"
  BODY="The SSL certificate for $DOMAIN will expire in $DAYS_LEFT days.

Expiry date: $EXPIRY

Action required:
1. Generate a renewal CSR: sudo ./deploy/ssl/ssl_renew.sh
2. Submit to your CA (DigiCert/GlobalSign)
3. Install the new certificate
4. Verify: sudo ./deploy/ssl/ssl_verify.sh

Server: $(hostname)
Certificate: $CERT_FILE"

  echo "$BODY" | mail -s "$SUBJECT" "$ALERT_EMAIL" 2>/dev/null || \
  logger -t ssl-expiry-check "WARNING: SSL cert for $DOMAIN expires in $DAYS_LEFT days"

  echo "$(date): SSL cert for $DOMAIN expires in $DAYS_LEFT days — alert sent" \
    >> /var/log/atoll-dashboard/ssl-expiry.log
fi
