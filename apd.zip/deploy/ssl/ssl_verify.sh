#!/bin/bash
# =============================================================================
# ssl_verify.sh — Verify SSL certificate health at any time
# Usage: ./ssl_verify.sh
#        ./ssl_verify.sh dashboard.yourcompany.com   (test live domain)
# =============================================================================

DOMAIN="${1:-dashboard.yourcompany.com}"
SSL_DIR="/etc/pki/tls"
CERT_DIR="$SSL_DIR/certs"
KEY_DIR="$SSL_DIR/private"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}✅ PASS${NC}  $1"; }
fail() { echo -e "  ${RED}❌ FAIL${NC}  $1"; FAILED=1; }
warn() { echo -e "  ${YELLOW}⚠️  WARN${NC}  $1"; }
FAILED=0

echo ""
echo "═════════════════════════════════════════════════"
echo "  SSL Certificate Health Check — $DOMAIN"
echo "═════════════════════════════════════════════════"
echo ""

CERT_FILE="$CERT_DIR/$DOMAIN.crt"
KEY_FILE="$KEY_DIR/$DOMAIN.key"
CHAIN_FILE="$CERT_DIR/$DOMAIN-chain.crt"

# ── 1. File existence ──────────────────────────────────────────────────────
echo "1. Certificate Files"
[[ -f "$CERT_FILE"  ]] && pass "Certificate file exists: $CERT_FILE"  || fail "Certificate missing: $CERT_FILE"
[[ -f "$KEY_FILE"   ]] && pass "Private key exists: $KEY_FILE"        || fail "Private key missing: $KEY_FILE"
[[ -f "$CHAIN_FILE" ]] && pass "CA bundle exists: $CHAIN_FILE"        || warn "CA bundle missing: $CHAIN_FILE (may cause chain errors)"
echo ""

# ── 2. File permissions ────────────────────────────────────────────────────
echo "2. File Permissions"
if [[ -f "$KEY_FILE" ]]; then
  PERMS=$(stat -c "%a" "$KEY_FILE")
  [[ "$PERMS" == "600" ]] && pass "Private key permissions: 600 (secure)" || fail "Private key permissions: $PERMS (should be 600)"
fi
if [[ -f "$CERT_FILE" ]]; then
  PERMS=$(stat -c "%a" "$CERT_FILE")
  [[ "$PERMS" == "644" || "$PERMS" == "600" ]] && pass "Certificate permissions: $PERMS (OK)" || warn "Certificate permissions: $PERMS (expected 644)"
fi
echo ""

# ── 3. Certificate validity dates ─────────────────────────────────────────
echo "3. Certificate Dates"
if [[ -f "$CERT_FILE" ]]; then
  NOT_BEFORE=$(openssl x509 -in "$CERT_FILE" -noout -startdate 2>/dev/null | cut -d= -f2)
  NOT_AFTER=$(openssl x509  -in "$CERT_FILE" -noout -enddate   2>/dev/null | cut -d= -f2)

  echo "     Valid from : $NOT_BEFORE"
  echo "     Valid until: $NOT_AFTER"

  EXPIRY_EPOCH=$(date -d "$NOT_AFTER" +%s 2>/dev/null || date -j -f "%b %d %T %Y %Z" "$NOT_AFTER" +%s)
  NOW_EPOCH=$(date +%s)
  DAYS_LEFT=$(( (EXPIRY_EPOCH - NOW_EPOCH) / 86400 ))

  if   [[ $DAYS_LEFT -lt 0   ]]; then fail "Certificate EXPIRED $((DAYS_LEFT * -1)) days ago!"
  elif [[ $DAYS_LEFT -lt 14  ]]; then fail "Expires in $DAYS_LEFT days — renew IMMEDIATELY"
  elif [[ $DAYS_LEFT -lt 30  ]]; then warn "Expires in $DAYS_LEFT days — start renewal process"
  elif [[ $DAYS_LEFT -lt 60  ]]; then warn "Expires in $DAYS_LEFT days — plan renewal soon"
  else                                 pass "Expires in $DAYS_LEFT days"
  fi

  # Check if cert is active (not before today)
  openssl x509 -in "$CERT_FILE" -noout -checkend 0 &>/dev/null && \
    pass "Certificate is currently valid" || fail "Certificate is not yet valid or already expired"
fi
echo ""

# ── 4. Certificate and key match ──────────────────────────────────────────
echo "4. Certificate ↔ Key Match"
if [[ -f "$CERT_FILE" && -f "$KEY_FILE" ]]; then
  CERT_MOD=$(openssl x509 -noout -modulus -in "$CERT_FILE" 2>/dev/null | md5sum)
  KEY_MOD=$(openssl  rsa  -noout -modulus -in "$KEY_FILE"  2>/dev/null | md5sum)
  [[ "$CERT_MOD" == "$KEY_MOD" ]] && pass "Certificate and key match" || fail "Certificate and key DO NOT match"
fi
echo ""

# ── 5. Certificate details ────────────────────────────────────────────────
echo "5. Certificate Details"
if [[ -f "$CERT_FILE" ]]; then
  CN=$(openssl x509 -in "$CERT_FILE" -noout -subject 2>/dev/null | grep -o "CN=[^,/]*" | cut -d= -f2)
  ISSUER=$(openssl x509 -in "$CERT_FILE" -noout -issuer 2>/dev/null | grep -o "O=[^,/]*" | head -1 | cut -d= -f2)
  SANS=$(openssl x509 -in "$CERT_FILE" -noout -ext subjectAltName 2>/dev/null | grep -v "X509" | tr -d ' ')

  echo "     Issued to : $CN"
  echo "     Issued by : $ISSUER"
  echo "     SANs      : $SANS"

  [[ "$CN" == "$DOMAIN" || "$CN" == "*.$DOMAIN" ]] && \
    pass "Domain matches certificate CN" || warn "Domain mismatch: cert CN='$CN', expected '$DOMAIN'"
fi
echo ""

# ── 6. Apache config ──────────────────────────────────────────────────────
echo "6. Apache Configuration"
if apachectl configtest 2>&1 | grep -q "Syntax OK"; then
  pass "Apache config syntax OK"
else
  fail "Apache config has errors"
fi

if systemctl is-active --quiet httpd; then
  pass "Apache HTTPD is running"
else
  fail "Apache HTTPD is NOT running"
fi

# Check port 443 is listening
if ss -tlnp | grep -q ":443"; then
  pass "Port 443 is open and listening"
else
  fail "Port 443 is NOT listening — Apache may not have loaded SSL"
fi
echo ""

# ── 7. Live HTTPS test ────────────────────────────────────────────────────
echo "7. Live Connection Test"
if command -v curl &>/dev/null; then
  HTTP_CODE=$(curl -sk -o /dev/null -w "%{http_code}" --max-time 5 "https://$DOMAIN/health" 2>/dev/null || echo "000")
  if [[ "$HTTP_CODE" == "200" ]]; then
    pass "HTTPS health endpoint responds: HTTP $HTTP_CODE"
  elif [[ "$HTTP_CODE" == "000" ]]; then
    warn "Could not connect — server may not be reachable from here"
  else
    warn "HTTPS health check returned: HTTP $HTTP_CODE"
  fi

  # Check redirect from HTTP to HTTPS
  REDIRECT=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://$DOMAIN" 2>/dev/null || echo "000")
  [[ "$REDIRECT" == "301" || "$REDIRECT" == "302" ]] && \
    pass "HTTP redirects to HTTPS (HTTP $REDIRECT)" || \
    warn "HTTP redirect not working (got HTTP $REDIRECT)"
fi
echo ""

# ── Summary ───────────────────────────────────────────────────────────────
if [[ $FAILED -eq 0 ]]; then
  echo -e "${GREEN}All checks passed — SSL is healthy! 🔒${NC}"
else
  echo -e "${RED}Some checks failed — see above for details.${NC}"
fi
echo ""
