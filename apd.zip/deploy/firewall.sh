#!/bin/bash
# =============================================================================
# firewall.sh  —  Open only the ports needed for the dashboard
# =============================================================================
# Usage:
#   chmod +x firewall.sh
#   sudo ./firewall.sh

echo "Configuring firewall..."

# Detect which firewall tool is available
if command -v ufw &>/dev/null; then
  # ── Ubuntu / Debian — UFW ────────────────────────────────────────────
  echo "Using UFW (Ubuntu/Debian)..."

  ufw --force enable
  ufw default deny incoming
  ufw default allow outgoing

  # SSH — keep your existing SSH access open
  ufw allow ssh

  # HTTP — port 80 for the dashboard
  ufw allow 80/tcp

  # HTTPS — port 443 (needed if you add SSL later)
  ufw allow 443/tcp

  # Port 3001 — API server (BLOCK from outside, NGINX proxies it internally)
  ufw deny 3001/tcp

  ufw reload
  ufw status verbose

elif command -v firewall-cmd &>/dev/null; then
  # ── CentOS / RHEL — firewalld ────────────────────────────────────────
  echo "Using firewalld (CentOS/RHEL)..."

  systemctl enable --now firewalld

  firewall-cmd --permanent --add-service=ssh
  firewall-cmd --permanent --add-service=http
  firewall-cmd --permanent --add-service=https

  # Remove direct access to port 3001 — only NGINX should reach it
  firewall-cmd --permanent --remove-port=3001/tcp 2>/dev/null || true

  firewall-cmd --reload
  firewall-cmd --list-all

else
  echo "No UFW or firewalld found. Configure your firewall manually."
  echo "Required: open port 80 (HTTP), 443 (HTTPS), 22 (SSH)"
  echo "Block:    port 3001 (API — only localhost should access it)"
fi

echo ""
echo "Firewall configured. Summary:"
echo "  ✅  Port 22  (SSH)   — open"
echo "  ✅  Port 80  (HTTP)  — open"
echo "  ✅  Port 443 (HTTPS) — open"
echo "  🔒  Port 3001 (API)  — blocked externally (NGINX proxies internally)"
