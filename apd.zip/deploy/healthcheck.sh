#!/bin/bash
# =============================================================================
# healthcheck.sh — Verify deployment health
# Usage: /apps/opt/jpuv/apps/atoll-dashboard/deploy/healthcheck.sh [url]
# =============================================================================

BASE_URL="${1:-http://localhost}"
DB_NAME="cgeventsdb"
DB_USER="cgeventsuser"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}✅ PASS${NC}  $1"; }
fail() { echo -e "  ${RED}❌ FAIL${NC}  $1"; FAILED=1; }
warn() { echo -e "  ${YELLOW}⚠️  WARN${NC}  $1"; }
FAILED=0

echo ""
echo "═════════════════════════════════════════════════"
echo "  Health Check — Atoll Pipeline Dashboard"
echo "  Target: $BASE_URL"
echo "═════════════════════════════════════════════════"
echo ""

# Check Apache HTTPD
if systemctl is-active --quiet httpd 2>/dev/null; then
  pass "Apache HTTPD is running"
else
  fail "Apache HTTPD is NOT running — run: sudo systemctl start httpd"
fi

# Check PM2 process
if sudo -u atoll pm2 list 2>/dev/null | grep -q "atoll-api.*online"; then
  pass "PM2 'atoll-api' process is running"
else
  fail "PM2 'atoll-api' is NOT running — run: sudo -u atoll pm2 start /apps/opt/jpuv/apps/atoll-dashboard/ecosystem.config.js"
fi

# Check HTTP endpoints
for endpoint in "" "/health" "/api/summary" "/api/servers" "/api/timeline" "/api/stages" "/api/recent"; do
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 3 "$BASE_URL$endpoint" 2>/dev/null || echo "000")
  if [[ "$HTTP_CODE" == "200" ]]; then
    if [[ "$endpoint" == "" ]]; then
      pass "Dashboard UI  ($BASE_URL)"
    else
      pass "$(echo $endpoint | cut -d'/' -f2,3) endpoint  ($BASE_URL$endpoint)"
    fi
  else
    if [[ "$endpoint" == "" ]]; then
      fail "Dashboard UI — HTTP $HTTP_CODE"
    else
      fail "$(echo $endpoint | cut -d'/' -f2,3) — HTTP $HTTP_CODE"
    fi
  fi
done

# Check PostgreSQL connection
if command -v psql &>/dev/null; then
  if PGPASSWORD="" psql -h localhost -U "$DB_USER" -d "$DB_NAME" -c "SELECT 1" &>/dev/null; then
    pass "PostgreSQL connection OK"
    
    # Check table exists and row count
    PE_COUNT=$(PGPASSWORD="" psql -h localhost -U "$DB_USER" -d "$DB_NAME" -t -c "SELECT COUNT(*) FROM radio.pipeline_errors" 2>/dev/null | tr -d ' ')
    AI_COUNT=$(PGPASSWORD="" psql -h localhost -U "$DB_USER" -d "$DB_NAME" -t -c "SELECT COUNT(*) FROM radio.aws_instances" 2>/dev/null | tr -d ' ')
    
    if [[ -n "$PE_COUNT" ]]; then
      pass "pipeline_errors table has $PE_COUNT rows"
    else
      warn "Cannot query pipeline_errors table"
    fi
    
    if [[ -n "$AI_COUNT" ]]; then
      pass "aws_instances table has $AI_COUNT servers"
    else
      warn "Cannot query aws_instances table"
    fi
  else
    fail "PostgreSQL connection failed — check cgeventsuser password"
  fi
else
  warn "psql not installed on this machine — cannot test DB connection"
fi

# Check disk space
DISK_USAGE=$(df -h /apps | tail -1 | awk '{print $5}' | tr -d '%')
if [[ "$DISK_USAGE" -lt 80 ]]; then
  pass "Disk usage: ${DISK_USAGE}% (/apps)"
elif [[ "$DISK_USAGE" -lt 90 ]]; then
  warn "Disk usage: ${DISK_USAGE}% (/apps) — consider cleanup"
else
  fail "Disk usage: ${DISK_USAGE}% (/apps) — CRITICAL"
fi

echo ""
if [[ $FAILED -eq 0 ]]; then
  echo -e "${GREEN}All checks passed! Dashboard is healthy.${NC}"
else
  echo -e "${RED}Some checks failed — see above for details.${NC}"
fi
echo ""
