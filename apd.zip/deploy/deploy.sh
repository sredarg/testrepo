#!/bin/bash
# =============================================================================
# deploy.sh — Atoll Pipeline Dashboard — RHEL 9 Production Deployment
# Apache HTTPD + Node.js 18 + PM2 + PostgreSQL
# =============================================================================
# CUSTOMIZED FOR:
#   - Database: cgeventsdb (existing)
#   - DB User: cgeventsuser (existing)
#   - Install Path: /apps/opt/jpuv/apps/atoll-dashboard
# =============================================================================
# Usage:
#   chmod +x deploy.sh
#   sudo ./deploy.sh
# =============================================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[ OK ]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERR ]${NC} $1"; exit 1; }

# ══ EDIT THESE BEFORE RUNNING ══════════════════════════════════════════════
SERVER_NAME="your-server-ip-or-domain.com"   # e.g., 10.0.1.50 or dashboard.company.com

# Database (ALREADY CONFIGURED)
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="cgeventsdb"                          # EXISTING database
DB_USER="cgeventsuser"                        # EXISTING user
DB_PASSWORD="CHANGE_THIS_PASSWORD"            # cgeventsuser's password

# Application Paths (CUSTOMIZED)
APP_DIR="/apps/opt/jpuv/apps/atoll-dashboard" # App install location
WEB_DIR="/var/www/atoll-dashboard"            # Apache web root
LOG_DIR="/var/log/atoll-dashboard"            # Application logs
APP_USER="atoll"                              # System user for Node.js
# ═══════════════════════════════════════════════════════════════════════════

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║   Atoll Pipeline Dashboard — RHEL 9 Production Deployment        ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "  Database    : $DB_NAME (existing)"
echo "  DB User     : $DB_USER (existing)"
echo "  Install Dir : $APP_DIR"
echo "  Web Root    : $WEB_DIR"
echo ""

[[ $EUID -ne 0 ]] && error "Run as root: sudo ./deploy.sh"

# Detect OS
if ! grep -q "Red Hat\|Rocky\|CentOS" /etc/os-release; then
    error "This script is for RHEL/Rocky/CentOS only"
fi
info "Detected: $(grep PRETTY_NAME /etc/os-release | cut -d'"' -f2)"

# ═══════════════════════════════════════════════════════════════════════════
# STEP 1 — Install Node.js 18
# ═══════════════════════════════════════════════════════════════════════════
info "Step 1/9 — Installing Node.js 18 LTS..."
if command -v node &>/dev/null && [[ $(node -v | cut -d. -f1 | tr -d v) -ge 18 ]]; then
    success "Node.js $(node -v) already installed"
else
    curl -fsSL https://rpm.nodesource.com/setup_18.x | bash -
    yum install -y nodejs
    success "Node.js $(node -v) installed"
fi

# ═══════════════════════════════════════════════════════════════════════════
# STEP 2 — Install Apache HTTPD
# ═══════════════════════════════════════════════════════════════════════════
info "Step 2/9 — Installing Apache HTTPD..."
if systemctl is-active --quiet httpd 2>/dev/null; then
    success "Apache already running"
else
    yum install -y httpd mod_ssl
    systemctl enable httpd
    systemctl start httpd
    success "Apache installed and started"
fi

# Critical SELinux setting for mod_proxy
info "  Enabling SELinux boolean for Apache proxy..."
setsebool -P httpd_can_network_connect 1
success "  SELinux configured for mod_proxy"

# ═══════════════════════════════════════════════════════════════════════════
# STEP 3 — Install PM2
# ═══════════════════════════════════════════════════════════════════════════
info "Step 3/9 — Installing PM2..."
if command -v pm2 &>/dev/null; then
    success "PM2 $(pm2 -v) already installed"
else
    npm install -g pm2
    success "PM2 $(pm2 -v) installed"
fi

# ═══════════════════════════════════════════════════════════════════════════
# STEP 4 — Create system user and directories
# ═══════════════════════════════════════════════════════════════════════════
info "Step 4/9 — Creating system user and directories..."

if ! id "$APP_USER" &>/dev/null; then
    useradd --system --no-create-home --shell /usr/sbin/nologin "$APP_USER"
    success "System user '$APP_USER' created"
else
    success "User '$APP_USER' already exists"
fi

mkdir -p "$APP_DIR" "$WEB_DIR" "$LOG_DIR"
chown "$APP_USER:$APP_USER" "$APP_DIR" "$LOG_DIR"
success "Directories created"

# ═══════════════════════════════════════════════════════════════════════════
# STEP 5 — Deploy application files
# ═══════════════════════════════════════════════════════════════════════════
info "Step 5/9 — Deploying application files..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Check if we're running from the extracted project or need to copy
if [[ "$PROJECT_ROOT" == "$APP_DIR" ]]; then
    info "  Already in target directory: $APP_DIR"
else
    info "  Copying project files from $PROJECT_ROOT to $APP_DIR..."
    cp -r "$PROJECT_ROOT/server"      "$APP_DIR/"
    cp -r "$PROJECT_ROOT/src"         "$APP_DIR/"
    cp -r "$PROJECT_ROOT/public"      "$APP_DIR/"
    cp    "$PROJECT_ROOT/package.json" "$APP_DIR/"
    cp    "$PROJECT_ROOT/tsconfig.json" "$APP_DIR/"
    cp -r "$PROJECT_ROOT/deploy"      "$APP_DIR/"
fi

# Write the production .env file
cat > "$APP_DIR/server/.env" << ENV_EOF
NODE_ENV=production
PORT=3001
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
ALLOWED_ORIGINS=http://$SERVER_NAME
ENV_EOF

chmod 600 "$APP_DIR/server/.env"
chown "$APP_USER:$APP_USER" "$APP_DIR/server/.env"
success "Environment config written"

# Install backend dependencies
info "  Installing backend Node.js dependencies..."
cd "$APP_DIR/server"
npm install --production --silent
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
success "  Backend dependencies installed"

# Build React frontend
info "  Building React frontend (takes ~60 seconds)..."
cd "$APP_DIR"
npm install --silent
REACT_APP_API_URL=/api npm run build
success "  React build complete"

# Copy build + .htaccess to web root
cp -r "$APP_DIR/build/." "$WEB_DIR/"
cp "$APP_DIR/deploy/httpd/.htaccess" "$WEB_DIR/.htaccess"

chown -R apache:apache "$WEB_DIR"
chmod -R 755 "$WEB_DIR"
restorecon -R "$WEB_DIR"
success "Web files deployed to $WEB_DIR"

# ═══════════════════════════════════════════════════════════════════════════
# STEP 6 — Configure Apache HTTPD
# ═══════════════════════════════════════════════════════════════════════════
info "Step 6/9 — Configuring Apache HTTPD..."

APACHE_CONF="/etc/httpd/conf.d/atoll-dashboard.conf"

cat > "$APACHE_CONF" << APACHECONF
<VirtualHost *:80>
    ServerName   $SERVER_NAME
    DocumentRoot $WEB_DIR

    ErrorLog  /var/log/httpd/atoll-dashboard-error.log
    CustomLog /var/log/httpd/atoll-dashboard-access.log combined

    <Directory $WEB_DIR>
        Options -Indexes -FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    <IfModule mod_rewrite.c>
        RewriteEngine On
        RewriteBase /
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteCond %{REQUEST_URI} !^/api
        RewriteCond %{REQUEST_URI} !^/health
        RewriteRule ^ /index.html [L]
    </IfModule>

    <IfModule mod_proxy.c>
        ProxyRequests     Off
        ProxyPreserveHost On
        ProxyPass        /api    http://127.0.0.1:3001/api
        ProxyPassReverse /api    http://127.0.0.1:3001/api
        ProxyPass        /health http://127.0.0.1:3001/health
        ProxyPassReverse /health http://127.0.0.1:3001/health
        RequestHeader set X-Real-IP       "%{REMOTE_ADDR}e"
        RequestHeader set X-Forwarded-For "%{REMOTE_ADDR}e"
    </IfModule>

    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json
    </IfModule>

    <IfModule mod_headers.c>
        Header always set X-Frame-Options        "SAMEORIGIN"
        Header always set X-Content-Type-Options "nosniff"
        Header always set X-XSS-Protection       "1; mode=block"
        Header unset Server
    </IfModule>

    <FilesMatch "^\\.">
        Require all denied
    </FilesMatch>
</VirtualHost>
APACHECONF

apachectl configtest 2>&1 | grep -E "(Syntax OK|Error)" || true
systemctl reload httpd
success "Apache configured and reloaded"

# ═══════════════════════════════════════════════════════════════════════════
# STEP 7 — Database setup
# ═══════════════════════════════════════════════════════════════════════════
info "Step 7/9 — Running database setup..."
if command -v psql &>/dev/null; then
    PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" \
        -U "$DB_USER" -d "$DB_NAME" \
        -f "$APP_DIR/deploy/db/db_setup_production.sql" &>/dev/null && \
        success "Database schema applied" || \
        warn "DB setup had warnings — check manually if needed"
else
    warn "psql not found — run deploy/db/db_setup_production.sql manually"
fi

# ═══════════════════════════════════════════════════════════════════════════
# STEP 8 — Start API server with PM2
# ═══════════════════════════════════════════════════════════════════════════
info "Step 8/9 — Starting API server with PM2..."

cp "$APP_DIR/deploy/pm2/ecosystem.config.js" "$APP_DIR/"
sed -i "s|/opt/atoll-dashboard|$APP_DIR|g" "$APP_DIR/ecosystem.config.js"

su -s /bin/bash "$APP_USER" -c "cd $APP_DIR && pm2 start ecosystem.config.js" 2>/dev/null
su -s /bin/bash "$APP_USER" -c "pm2 save" 2>/dev/null

# Set PM2 to start on boot
PM2_STARTUP=$(env PATH=$PATH:/usr/bin pm2 startup systemd -u "$APP_USER" --hp "/home/$APP_USER" 2>/dev/null | grep "sudo" | tail -1)
[[ -n "$PM2_STARTUP" ]] && eval "$PM2_STARTUP" &>/dev/null || true
success "API server running with PM2"

# ═══════════════════════════════════════════════════════════════════════════
# STEP 9 — Firewall
# ═══════════════════════════════════════════════════════════════════════════
info "Step 9/9 — Configuring firewall..."
if command -v firewall-cmd &>/dev/null; then
    firewall-cmd --permanent --add-service=http &>/dev/null
    firewall-cmd --permanent --add-service=ssh  &>/dev/null
    firewall-cmd --permanent --add-service=https &>/dev/null
    firewall-cmd --reload &>/dev/null
    success "firewalld configured (port 80/443 open)"
else
    warn "firewalld not found — open port 80 manually"
fi

# ═══════════════════════════════════════════════════════════════════════════
# Done
# ═══════════════════════════════════════════════════════════════════════════
echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║                ✅  Deployment Complete!                          ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo -e "  Dashboard URL : ${GREEN}http://$SERVER_NAME${NC}"
echo -e "  Health check  : ${GREEN}http://$SERVER_NAME/health${NC}"
echo -e "  API base URL  : ${GREEN}http://$SERVER_NAME/api${NC}"
echo ""
echo "  Useful commands:"
echo "    pm2 status                          — API server status"
echo "    pm2 logs atoll-api                  — Live API logs"
echo "    sudo systemctl status httpd         — Apache status"
echo "    sudo tail -f /var/log/httpd/atoll-dashboard-error.log"
echo ""
echo "  Application location: $APP_DIR"
echo "  Web root:             $WEB_DIR"
echo "  Logs:                 $LOG_DIR"
echo ""
warn "Next steps:"
echo "  • Verify: $APP_DIR/deploy/healthcheck.sh"
echo "  • Add HTTPS: sudo $APP_DIR/deploy/ssl/ssl_setup.sh"
echo "  • Schedule cleanup: sudo crontab -e"
echo "      0 2 * * * $APP_DIR/deploy/cron/cleanup.sh"
echo ""
