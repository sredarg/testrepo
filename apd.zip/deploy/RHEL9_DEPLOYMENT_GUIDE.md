# Atoll Pipeline Dashboard — RHEL 9 Deployment Guide
## Customized for Your Production Environment

---

## 📋 Your Environment

```
Database:      cgeventsdb (EXISTING)
Schema:        radio (EXISTING)
DB Admin:      cgeventsadmin
DB App User:   cgeventsuser (EXISTING)

Existing Tables:
  • radio.aws_instances
  • radio.aws_technology
  • radio.aws_jobs

New Table:
  • radio.pipeline_errors (will be created)

Install Path:  /apps/opt/jpuv/apps/atoll-dashboard
Web Root:      /var/www/atoll-dashboard
Logs:          /var/log/atoll-dashboard

Server:        RHEL 9
Web Server:    Apache HTTPD (httpd)
Runtime:       Node.js 18 LTS
Process Mgr:   PM2
```

---

## 🚀 Quick Start (Automated Deployment)

### Step 1: Edit Configuration

```bash
cd /apps/opt/jpuv/apps/atoll-dashboard/deploy
nano deploy.sh
```

Change these three values at the top:
```bash
SERVER_NAME="10.0.1.50"                           # Your server IP or hostname
DB_PASSWORD="your_cgeventsuser_password"          # Password for cgeventsuser
```

### Step 2: Run Deployment Script

```bash
chmod +x deploy.sh
sudo ./deploy.sh
```

The script automatically:
- ✅ Installs Node.js 18, Apache HTTPD, PM2
- ✅ Creates system user `atoll`
- ✅ Writes `.env` with database credentials
- ✅ Installs dependencies
- ✅ Builds React frontend
- ✅ Configures Apache VirtualHost
- ✅ Creates `radio.pipeline_errors` table
- ✅ Starts API with PM2
- ✅ Opens firewall port 80
- ✅ Enables auto-start on reboot

**Total time: 5–10 minutes**

### Step 3: Verify

```bash
./healthcheck.sh
```

Expected output:
```
✅ PASS  Apache HTTPD is running
✅ PASS  PM2 'atoll-api' process is running
✅ PASS  Dashboard UI
✅ PASS  Health endpoint
✅ PASS  All API endpoints responding
✅ PASS  PostgreSQL connection OK
✅ PASS  pipeline_errors table created
✅ PASS  aws_instances table has N servers
```

Open in browser: `http://your-server-ip`

---

## 📂 File Locations After Deployment

```
/apps/opt/jpuv/apps/atoll-dashboard/
├── server/
│   ├── index.js                      ← Express API server
│   ├── .env                          ← DB credentials (chmod 600)
│   └── node_modules/
├── build/                            ← React production build
├── deploy/
│   ├── deploy.sh                     ← One-command deployment
│   ├── update.sh                     ← Re-deploy after code changes
│   ├── healthcheck.sh                ← Verify all services
│   ├── httpd/
│   │   └── atoll-dashboard.conf      ← Apache config (copied to /etc/httpd/conf.d/)
│   ├── db/
│   │   └── db_setup_production.sql   ← Creates pipeline_errors table
│   └── pm2/
│       └── ecosystem.config.js       ← PM2 process config
└── ecosystem.config.js               ← Active PM2 config

/var/www/atoll-dashboard/             ← Apache serves from here
├── index.html
├── .htaccess                         ← React Router support
└── static/                           ← JS, CSS, images

/etc/httpd/conf.d/
└── atoll-dashboard.conf              ← Apache VirtualHost config

/var/log/
├── httpd/
│   ├── atoll-dashboard-access.log
│   └── atoll-dashboard-error.log
└── atoll-dashboard/                  ← PM2 app logs
    ├── combined.log
    ├── out.log
    └── error.log
```

---

## 🗄️ Database Setup Details

The deployment creates **only one new table**: `radio.pipeline_errors`

### What Gets Created

| Object | Name | Purpose |
|--------|------|---------|
| **Table** | `radio.pipeline_errors` | Stores all error records from Atoll pipeline |
| **Foreign Key** | `fk_instance` | Links to `radio.aws_instances(instance_id)` |
| **Index** | `idx_pe_instance_id` | Fast JOIN with aws_instances |
| **Index** | `idx_pe_timestamp` | Fast recent errors queries |
| **Index** | `idx_pe_resolved` | Partial index on unresolved errors |
| **Index** | `idx_pe_severity` | Fast filtering by severity |
| **Index** | `idx_pe_instance_timestamp` | Dashboard summary optimization |

### Permissions Granted to `cgeventsuser`

```sql
-- Read access to existing tables
GRANT SELECT ON radio.aws_instances TO cgeventsuser;
GRANT SELECT ON radio.aws_technology TO cgeventsuser;
GRANT SELECT ON radio.aws_jobs TO cgeventsuser;

-- Full access to new table
GRANT SELECT, INSERT, UPDATE, DELETE ON radio.pipeline_errors TO cgeventsuser;
```

### Manual Database Setup (If Needed)

If the automated deployment didn't run the DB script:

```bash
psql -h localhost -U cgeventsadmin -d cgeventsdb \
     -f /apps/opt/jpuv/apps/atoll-dashboard/deploy/db/db_setup_production.sql
```

Or as postgres superuser:
```bash
sudo -u postgres psql -d cgeventsdb \
     -f /apps/opt/jpuv/apps/atoll-dashboard/deploy/db/db_setup_production.sql
```

Verify table was created:
```bash
psql -h localhost -U cgeventsuser -d cgeventsdb \
     -c "\d radio.pipeline_errors"
```

---

## ⚙️ Day-to-Day Operations

### Check Status

```bash
# All services
sudo systemctl status httpd                           # Apache
sudo -u atoll pm2 status                              # API server
/apps/opt/jpuv/apps/atoll-dashboard/deploy/healthcheck.sh

# Quick verification
curl http://localhost/health
```

### View Logs

```bash
# API server logs (live)
sudo -u atoll pm2 logs atoll-api

# API logs (last 50 lines)
sudo -u atoll pm2 logs atoll-api --lines 50

# Apache error log
sudo tail -f /var/log/httpd/atoll-dashboard-error.log

# Apache access log (who's using the dashboard)
sudo tail -f /var/log/httpd/atoll-dashboard-access.log
```

### Restart Services

```bash
# Restart API (zero-downtime reload — preferred)
sudo -u atoll pm2 reload atoll-api

# Restart API (hard restart)
sudo -u atoll pm2 restart atoll-api

# Restart Apache (reload config, no downtime)
sudo systemctl reload httpd

# Restart Apache (full restart)
sudo systemctl restart httpd
```

### Update After Code Changes

When you modify the React frontend or Node.js backend:

```bash
sudo /apps/opt/jpuv/apps/atoll-dashboard/deploy/update.sh
```

This script:
1. Installs new Node.js dependencies
2. Rebuilds React frontend
3. Copies new build to `/var/www/atoll-dashboard/`
4. Zero-downtime reload of API server

---

## 🔧 RHEL 9 Specific Notes

### SELinux — CRITICAL Configuration

RHEL 9 enforces SELinux by default. **This step is mandatory** or Apache will not be able to proxy to Node.js:

```bash
# Allow Apache to make network connections (required for mod_proxy)
sudo setsebool -P httpd_can_network_connect 1

# Verify it's set
sudo getsebool httpd_can_network_connect
# Should return: httpd_can_network_connect --> on
```

**This is included in the deployment script, but if you ever get 502 errors, verify this boolean is ON.**

### Firewall (firewalld)

```bash
# Open HTTP (port 80)
sudo firewall-cmd --permanent --add-service=http

# Open HTTPS (port 443, for future SSL)
sudo firewall-cmd --permanent --add-service=https

# Apply changes
sudo firewall-cmd --reload

# Verify
sudo firewall-cmd --list-services
# Should show: ssh dhcpv6-client http https
```

### Apache Module Verification

```bash
# Check required modules are loaded
httpd -M | grep -E "proxy|rewrite|headers|deflate"

# Should see:
#  proxy_module (shared)
#  proxy_http_module (shared)
#  rewrite_module (shared)
#  headers_module (shared)
#  deflate_module (shared)
```

If any are missing:
```bash
sudo yum install -y mod_ssl mod_proxy_html
sudo systemctl restart httpd
```

---

## 🐛 Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| **502 Bad Gateway** | SELinux blocking proxy | `sudo setsebool -P httpd_can_network_connect 1` |
| **403 Forbidden** | Wrong permissions or SELinux | `sudo chown -R apache:apache /var/www/atoll-dashboard`<br>`sudo restorecon -R /var/www/atoll-dashboard` |
| **Can't connect** | Firewall blocking | `sudo firewall-cmd --add-service=http --permanent && sudo firewall-cmd --reload` |
| **Dashboard loads, no data** | DB password wrong | Check `/apps/opt/jpuv/apps/atoll-dashboard/server/.env`<br>Password must match `cgeventsuser` |
| **404 on refresh** | .htaccess not working | Confirm `AllowOverride All` in `/etc/httpd/conf.d/atoll-dashboard.conf` |
| **API won't start** | Port 3001 in use | `sudo ss -tlnp | grep 3001` — kill conflicting process |

### Quick Diagnostics

```bash
# 1. Is Apache running?
sudo systemctl status httpd

# 2. Is API running?
sudo -u atoll pm2 status

# 3. Can API reach DB?
sudo -u atoll pm2 logs atoll-api --lines 30

# 4. Can Apache reach API?
curl http://localhost:3001/health   # Direct
curl http://localhost/health        # Via Apache

# 5. SELinux blocking?
sudo ausearch -m avc -ts recent | grep httpd

# 6. Firewall OK?
sudo firewall-cmd --list-all
```

---

## 🔐 Security Checklist

After deployment, verify:

- [ ] `.env` file is `chmod 600` owned by `atoll` user
- [ ] `cgeventsuser` has a strong password
- [ ] Port 3001 is NOT open externally (only Apache can reach it)
- [ ] SELinux boolean `httpd_can_network_connect` is ON
- [ ] Apache security headers are set (X-Frame-Options, etc.)
- [ ] Only ports 22, 80, 443 are open in firewalld
- [ ] Dashboard URL is accessible from all company offices

---

## 📝 Environment File Reference

The `.env` file at `/apps/opt/jpuv/apps/atoll-dashboard/server/.env`:

```bash
NODE_ENV=production
PORT=3001
DB_HOST=localhost
DB_PORT=5432
DB_NAME=cgeventsdb
DB_USER=cgeventsuser
DB_PASSWORD=your_actual_password_here
ALLOWED_ORIGINS=http://your-server-ip-or-domain
```

**Security:**
- Never commit this file to git
- `chmod 600` (only owner can read)
- Owned by `atoll:atoll`
- After changing, restart API: `sudo -u atoll pm2 restart atoll-api`

---

## 🔄 Scheduled Maintenance (Optional)

Set up automated cleanup of old error records:

```bash
sudo crontab -e

# Add this line:
0 2 * * * /apps/opt/jpuv/apps/atoll-dashboard/deploy/cron/cleanup.sh >> /var/log/atoll-dashboard/cleanup.log 2>&1
```

This runs daily at 2 AM and:
- Deletes resolved errors older than 30 days
- Runs VACUUM ANALYZE on Sundays
- Rotates log files older than 7 days

---

## 📞 Support

**Deployment Issues:**
- Check `/var/log/httpd/atoll-dashboard-error.log`
- Check `sudo -u atoll pm2 logs atoll-api`
- Run `/apps/opt/jpuv/apps/atoll-dashboard/deploy/healthcheck.sh`

**Database Issues:**
- Verify `cgeventsuser` password is correct
- Test: `psql -h localhost -U cgeventsuser -d cgeventsdb -c "SELECT COUNT(*) FROM radio.pipeline_errors;"`
- Check grants: `psql -U cgeventsadmin -d cgeventsdb -c "\dp radio.pipeline_errors"`

**Performance Issues:**
- Check PM2 memory: `sudo -u atoll pm2 status` (look at memory column)
- Check disk space: `df -h /apps`
- Check DB indexes: `psql -U cgeventsuser -d cgeventsdb -c "\di radio.idx_pe*"`

---

## ✅ Final Checklist

Before declaring deployment complete:

- [ ] `deploy.sh` ran successfully with no errors
- [ ] `healthcheck.sh` shows all green checks
- [ ] Dashboard loads at `http://your-server-ip`
- [ ] All N servers appear in the Server Table
- [ ] Test error can be inserted and appears on dashboard
- [ ] Dashboard accessible from another office/computer
- [ ] PM2 configured to start on boot (`pm2 startup` completed)
- [ ] `.env` file has correct `cgeventsuser` password
- [ ] SELinux boolean `httpd_can_network_connect` is ON
- [ ] Firewall allows port 80
- [ ] Apache and PM2 both survive server reboot

---

## 🚀 Quick Command Reference

```bash
# Status
sudo systemctl status httpd
sudo -u atoll pm2 status

# Logs
sudo -u atoll pm2 logs atoll-api
sudo tail -f /var/log/httpd/atoll-dashboard-error.log

# Restart
sudo -u atoll pm2 reload atoll-api
sudo systemctl reload httpd

# Update code
sudo /apps/opt/jpuv/apps/atoll-dashboard/deploy/update.sh

# Health check
/apps/opt/jpuv/apps/atoll-dashboard/deploy/healthcheck.sh

# Database query
psql -h localhost -U cgeventsuser -d cgeventsdb -c "SELECT COUNT(*) FROM radio.pipeline_errors;"
```

---

**Your dashboard is now live at `http://your-server-ip` and will auto-refresh every 30 seconds to show the latest errors from your 300 Atoll servers.**
