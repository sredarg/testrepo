#!/bin/bash
# =============================================================================
# update.sh — Re-deploy after code changes (no full reinstall)
# Usage: sudo /apps/opt/jpuv/apps/atoll-dashboard/deploy/update.sh
# =============================================================================

set -e
GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[ OK ]${NC} $1"; }

APP_DIR="/apps/opt/jpuv/apps/atoll-dashboard"
WEB_DIR="/var/www/atoll-dashboard"
APP_USER="atoll"
APACHE_USER="apache"

echo ""
echo "Atoll Dashboard — Updating..."
echo "=============================="
echo ""

info "Updating backend dependencies..."
cd "$APP_DIR/server" && npm install --production --silent
chown -R "$APP_USER:$APP_USER" "$APP_DIR/server/node_modules"

info "Rebuilding React frontend..."
cd "$APP_DIR" && npm install --silent
REACT_APP_API_URL=/api npm run build

info "Updating web files..."
rm -rf "$WEB_DIR"/*
cp -r "$APP_DIR/build/." "$WEB_DIR/"
cp "$APP_DIR/deploy/httpd/.htaccess" "$WEB_DIR/.htaccess"
chown -R "$APACHE_USER:$APACHE_USER" "$WEB_DIR"
restorecon -R "$WEB_DIR"

info "Reloading API server (zero-downtime)..."
su -s /bin/bash "$APP_USER" -c "pm2 reload atoll-api"

success "Update complete!"
echo ""
echo "  pm2 status               — verify running"
echo "  pm2 logs atoll-api       — check for errors"
echo ""
