-- ============================================================================
-- Production Database Setup for Atoll Pipeline Dashboard
-- Database: cgeventsdb (EXISTING)
-- Schema: radio (EXISTING)
-- User: cgeventsuser (EXISTING)
-- RHEL 9 / PostgreSQL 12+
-- ============================================================================

\echo '═════════════════════════════════════════════════════════════'
\echo '  Atoll Pipeline Dashboard — Database Setup'
\echo '  Database: cgeventsdb'
\echo '  Schema: radio (existing)'
\echo '═════════════════════════════════════════════════════════════'

-- Verify schema exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'radio') THEN
        RAISE EXCEPTION 'Schema radio does not exist!';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'radio' AND table_name = 'aws_instances') THEN
        RAISE EXCEPTION 'Table radio.aws_instances does not exist!';
    END IF;
    RAISE NOTICE '✓ Schema radio and aws_instances table verified';
END $$;

-- Create pipeline_errors table
CREATE TABLE IF NOT EXISTS radio.pipeline_errors (
    error_id            SERIAL PRIMARY KEY,
    instance_id         VARCHAR(50) NOT NULL,
    error_timestamp     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    error_type          VARCHAR(100) NOT NULL,
    error_message       TEXT NOT NULL,
    pipeline_stage      VARCHAR(100),
    severity            VARCHAR(20) CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    resolved            BOOLEAN DEFAULT FALSE,
    resolved_timestamp  TIMESTAMP,
    resolved_by         VARCHAR(100),
    notes               TEXT,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_instance FOREIGN KEY (instance_id) REFERENCES radio.aws_instances(instance_id) ON DELETE CASCADE
);

\echo '✓ Table radio.pipeline_errors created'

-- Grant permissions to cgeventsuser
GRANT SELECT ON radio.aws_instances TO cgeventsuser;
GRANT SELECT ON radio.aws_technology TO cgeventsuser;
GRANT SELECT ON radio.aws_jobs TO cgeventsuser;
GRANT SELECT, INSERT, UPDATE, DELETE ON radio.pipeline_errors TO cgeventsuser;
GRANT USAGE, SELECT ON SEQUENCE radio.pipeline_errors_error_id_seq TO cgeventsuser;

\echo '✓ Permissions granted to cgeventsuser'

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_pe_instance_id ON radio.pipeline_errors(instance_id);
CREATE INDEX IF NOT EXISTS idx_pe_timestamp ON radio.pipeline_errors(error_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_pe_resolved ON radio.pipeline_errors(resolved, error_timestamp DESC) WHERE resolved = FALSE;
CREATE INDEX IF NOT EXISTS idx_pe_severity ON radio.pipeline_errors(severity);
CREATE INDEX IF NOT EXISTS idx_pe_instance_timestamp ON radio.pipeline_errors(instance_id, error_timestamp DESC);

\echo '✓ 5 indexes created'
\echo ''
\echo '═════════════════════════════════════════════════════════════'
\echo '  Setup Complete!'
\echo '═════════════════════════════════════════════════════════════'
\echo 'Update .env with: DB_NAME=cgeventsdb, DB_USER=cgeventsuser'
