#!/bin/bash
# =============================================================================
# cron/cleanup.sh  —  Scheduled maintenance tasks
# =============================================================================
# Add to crontab with:
#   sudo crontab -e
#
# Paste these lines:
#   # Run cleanup at 2am daily
#   0 2 * * * /opt/atoll-dashboard/deploy/cron/cleanup.sh >> /var/log/atoll-dashboard/cleanup.log 2>&1
# =============================================================================

set -e

# Load DB credentials from the app .env
source /opt/atoll-dashboard/server/.env

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
echo "[$TIMESTAMP] Starting cleanup..."

# 1. Delete errors older than 30 days
DELETED=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c "
  DELETE FROM radio.pipeline_errors
  WHERE error_timestamp < NOW() - INTERVAL '30 days'
  RETURNING error_id;
" | wc -l)
echo "[$TIMESTAMP] Deleted $DELETED old errors"

# 2. VACUUM to reclaim disk space (run weekly — only on Sunday)
DAY=$(date '+%u')
if [[ "$DAY" == "7" ]]; then
  psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -c "VACUUM ANALYZE radio.pipeline_errors;" > /dev/null
  echo "[$TIMESTAMP] VACUUM ANALYZE completed"
fi

# 3. Rotate app logs older than 7 days
find /var/log/atoll-dashboard -name "*.log" -mtime +7 -delete
echo "[$TIMESTAMP] Old log files cleaned"

echo "[$TIMESTAMP] Cleanup complete"
