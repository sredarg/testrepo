# Quick Start Guide - Atoll Pipeline Dashboard

## 🚀 Get Started in 5 Minutes

### Prerequisites
- Node.js 16+ installed
- PostgreSQL with radio.aws_instances table
- Access to database credentials

### 1. Database Setup (2 minutes)
```bash
# Run the schema script
psql -h YOUR_HOST -U YOUR_USER -d YOUR_DB -f database_schema.sql
```

### 2. Backend Setup (1 minute)
```bash
cd server
npm install
cp .env.example .env
# Edit .env with your database credentials
npm start
```

Server runs at: http://localhost:3001

### 3. Frontend Setup (1 minute)
```bash
cd ..
npm install
cp .env.example .env
# Edit .env if needed (default is localhost:3001)
npm start
```

Dashboard opens at: http://localhost:3000

### 4. Test It Out (1 minute)

Insert a test error:
```sql
INSERT INTO radio.pipeline_errors 
(instance_id, error_type, error_message, pipeline_stage, severity)
VALUES 
('i-test123', 'TestError', 'This is a test error', 'Testing', 'HIGH');
```

Refresh the dashboard - you should see it!

## 🎯 What You Get

✅ **Real-time error monitoring** across ~300 Windows servers
✅ **Server-level breakdown** showing which IPs/instances have issues  
✅ **24-hour timeline** of error trends
✅ **Pipeline stage analysis** to identify bottlenecks
✅ **Sortable/filterable tables** for quick debugging
✅ **Auto-refresh** every 30 seconds
✅ **Clean, professional UI** - no libraries needed

## 📊 Dashboard Features

**Top Cards:** Total errors, affected servers, active errors, critical count

**Server Table:** 
- Sort by any column (instance, IP, errors, etc.)
- Filter by instance ID or IP address
- See critical errors at a glance

**Timeline Chart:** Hourly breakdown of errors with critical overlay

**Stage Breakdown:** See which pipeline stages have the most errors

**Recent Errors:** 
- Expand to see full error messages
- Mark errors as resolved
- See timestamps and severity

## 🔄 Feeding Data to the Dashboard

### Option 1: Use the API
```bash
curl -X POST http://localhost:3001/api/errors \
  -H "Content-Type: application/json" \
  -d '{
    "instance_id": "i-abc123",
    "error_type": "TimeoutError",
    "error_message": "Pipeline timed out after 300s",
    "pipeline_stage": "Coverage Generation",
    "severity": "HIGH"
  }'
```

### Option 2: Direct SQL Insert
```sql
INSERT INTO radio.pipeline_errors 
    (instance_id, error_type, error_message, pipeline_stage, severity)
VALUES 
    ('i-server01', 'ConfigError', 'Missing config file', 'Init', 'MEDIUM');
```

### Option 3: Parse Your Logs
Write a script that monitors Atoll logs and posts errors to the API.
See README.md for PowerShell and Python examples.

## 🏗️ Production Deployment

**For Windows/IIS:**
```bash
npm run build
# Copy build/ folder to C:\inetpub\wwwroot\dashboard\
# Run server with: pm2 start index.js --name atoll-api
```

**For Linux/Nginx:**
```bash
npm run build
# Copy build/ to /var/www/dashboard/
# Run server with: pm2 start index.js --name atoll-api
```

See full deployment instructions in README.md

## 🎨 Customization

**Change refresh interval:**
Edit `src/components/Dashboard.tsx`, line ~50:
```typescript
interval = setInterval(fetchDashboardData, 30000); // 30 seconds
```

**Change time window (default 24h):**
Edit SQL queries in `server/index.js` to adjust:
```sql
WHERE error_timestamp >= NOW() - INTERVAL '24 hours'
```

**Add new severity levels:**
Edit the severity constraint in `database_schema.sql`

**Customize colors:**
Edit CSS files in `src/styles/`

## 📞 Need Help?

1. Check if API is running: http://localhost:3001/health
2. Check browser console for errors (F12)
3. Check server logs in the terminal
4. Verify database connection with: `psql -h HOST -U USER -d DB`
5. Read full README.md for detailed troubleshooting

## 🎯 Next Steps

Once it's working:
1. Set up error data collection from your Atoll pipeline
2. Deploy to production server
3. Set up automated cleanup of old errors
4. Consider adding email alerts for critical errors
5. Customize the dashboard to your needs

**Happy monitoring! 🚀**
