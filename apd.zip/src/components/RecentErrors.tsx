// src/components/RecentErrors.tsx
import React, { useState } from 'react';
import type { RecentError } from '../types';
import { api } from '../services/api';

interface Props {
  data: RecentError[];
}

export const RecentErrors: React.FC<Props> = ({ data }) => {
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [resolving, setResolving] = useState<number | null>(null);

  const handleResolve = async (errorId: number) => {
    setResolving(errorId);
    try {
      await api.resolveError(errorId);
      // In a real app, you'd refresh the data here
      alert('Error marked as resolved. Refresh to see changes.');
    } catch (error) {
      alert('Failed to resolve error');
    } finally {
      setResolving(null);
    }
  };

  const getSeverityClass = (severity: string) => {
    return `severity-${severity.toLowerCase()}`;
  };

  const toggleExpand = (errorId: number) => {
    setExpandedId(expandedId === errorId ? null : errorId);
  };

  if (data.length === 0) {
    return (
      <div className="recent-errors-container">
        <h2>Recent Errors</h2>
        <div className="no-data">No recent errors</div>
      </div>
    );
  }

  return (
    <div className="recent-errors-container">
      <h2>Recent Errors (Last 100)</h2>
      
      <div className="errors-list">
        {data.map((error) => (
          <div 
            key={error.error_id} 
            className={`error-item ${getSeverityClass(error.severity)} ${error.resolved ? 'resolved' : ''}`}
          >
            <div className="error-header" onClick={() => toggleExpand(error.error_id)}>
              <div className="error-main-info">
                <span className={`severity-badge ${getSeverityClass(error.severity)}`}>
                  {error.severity}
                </span>
                <span className="error-type">{error.error_type}</span>
                <span className="error-stage">{error.pipeline_stage}</span>
              </div>
              
              <div className="error-meta">
                <span className="error-instance">{error.instance_id}</span>
                <span className="error-ip">{error.ipaddress}</span>
                <span className="error-time">
                  {new Date(error.error_timestamp).toLocaleString()}
                </span>
              </div>

              <button 
                className="expand-btn"
                aria-label={expandedId === error.error_id ? 'Collapse' : 'Expand'}
              >
                {expandedId === error.error_id ? '▼' : '▶'}
              </button>
            </div>

            {expandedId === error.error_id && (
              <div className="error-details">
                <div className="error-message">
                  <strong>Error Message:</strong>
                  <pre>{error.error_message}</pre>
                </div>

                <div className="error-actions">
                  {!error.resolved && (
                    <button
                      onClick={() => handleResolve(error.error_id)}
                      disabled={resolving === error.error_id}
                      className="resolve-btn"
                    >
                      {resolving === error.error_id ? 'Resolving...' : 'Mark as Resolved'}
                    </button>
                  )}
                  {error.resolved && (
                    <span className="resolved-indicator">✓ Resolved</span>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
