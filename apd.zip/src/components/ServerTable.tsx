// src/components/ServerTable.tsx
import React, { useState, useMemo } from 'react';
import type { ServerError } from '../types';

interface Props {
  data: ServerError[];
}

export const ServerTable: React.FC<Props> = ({ data }) => {
  const [sortField, setSortField] = useState<keyof ServerError>('error_count');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [filter, setFilter] = useState<string>('');

  const sortedAndFiltered = useMemo(() => {
    let filtered = data;

    // Filter by instance_id or ipaddress
    if (filter) {
      filtered = data.filter(
        server => 
          server.instance_id.toLowerCase().includes(filter.toLowerCase()) ||
          server.ipaddress.toLowerCase().includes(filter.toLowerCase())
      );
    }

    // Sort
    return [...filtered].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDirection === 'asc' 
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      
      const aNum = Number(aVal);
      const bNum = Number(bVal);
      return sortDirection === 'asc' ? aNum - bNum : bNum - aNum;
    });
  }, [data, sortField, sortDirection, filter]);

  const handleSort = (field: keyof ServerError) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const getStatusBadge = (status: string) => {
    const statusClass = status.toLowerCase();
    return <span className={`status-badge ${statusClass}`}>{status}</span>;
  };

  const getSeverityClass = (hasCritical: number) => {
    return hasCritical ? 'row-critical' : '';
  };

  return (
    <div className="table-container">
      <div className="table-header">
        <h2>Errors by Server</h2>
        <input 
          type="text"
          placeholder="Filter by Instance ID or IP..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="filter-input"
        />
      </div>

      <div className="table-wrapper">
        <table className="server-table">
          <thead>
            <tr>
              <th onClick={() => handleSort('instance_id')}>
                Instance ID {sortField === 'instance_id' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('ipaddress')}>
                IP Address {sortField === 'ipaddress' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('server_status')}>
                Status {sortField === 'server_status' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('error_count')}>
                Total Errors {sortField === 'error_count' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('active_errors')}>
                Active {sortField === 'active_errors' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('last_error_time')}>
                Last Error {sortField === 'last_error_time' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th>Critical</th>
            </tr>
          </thead>
          <tbody>
            {sortedAndFiltered.length === 0 ? (
              <tr>
                <td colSpan={7} className="no-data">
                  {filter ? 'No servers match your filter' : 'No error data available'}
                </td>
              </tr>
            ) : (
              sortedAndFiltered.map((server) => (
                <tr 
                  key={server.instance_id}
                  className={getSeverityClass(server.has_critical_error)}
                >
                  <td className="mono">{server.instance_id}</td>
                  <td className="mono">{server.ipaddress}</td>
                  <td>{getStatusBadge(server.server_status)}</td>
                  <td>
                    <span className={server.error_count > 0 ? 'error-count' : ''}>
                      {server.error_count}
                    </span>
                  </td>
                  <td>
                    <span className={server.active_errors > 0 ? 'active-count' : ''}>
                      {server.active_errors}
                    </span>
                  </td>
                  <td>
                    {server.last_error_time 
                      ? new Date(server.last_error_time).toLocaleString()
                      : 'N/A'
                    }
                  </td>
                  <td>
                    {server.has_critical_error ? (
                      <span className="critical-indicator">🚨</span>
                    ) : (
                      '-'
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="table-footer">
        Showing {sortedAndFiltered.length} of {data.length} servers
      </div>
    </div>
  );
};
