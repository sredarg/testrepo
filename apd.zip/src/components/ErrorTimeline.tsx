// src/components/ErrorTimeline.tsx
import React from 'react';
import type { TimelineData } from '../types';

interface Props {
  data: TimelineData[];
}

export const ErrorTimeline: React.FC<Props> = ({ data }) => {
  if (data.length === 0) {
    return (
      <div className="chart-container">
        <h2>Error Timeline (24h)</h2>
        <div className="no-data">No timeline data available</div>
      </div>
    );
  }

  const maxErrors = Math.max(...data.map(d => d.error_count), 1);
  const chartHeight = 200;

  return (
    <div className="chart-container">
      <h2>Error Timeline (24h)</h2>
      
      <div className="chart-legend">
        <div className="legend-item">
          <span className="legend-color total"></span>
          <span>Total Errors</span>
        </div>
        <div className="legend-item">
          <span className="legend-color critical"></span>
          <span>Critical</span>
        </div>
      </div>

      <div className="timeline-chart">
        <svg width="100%" height={chartHeight + 40} className="chart-svg">
          {/* Y-axis labels */}
          <text x="5" y="15" className="axis-label">{maxErrors}</text>
          <text x="5" y={chartHeight / 2} className="axis-label">{Math.round(maxErrors / 2)}</text>
          <text x="5" y={chartHeight} className="axis-label">0</text>

          {/* Bars */}
          <g transform="translate(40, 0)">
            {data.map((point, index) => {
              const barWidth = (100 / data.length) * 0.8;
              const x = (index * 100) / data.length;
              const totalHeight = (point.error_count / maxErrors) * chartHeight;
              const criticalHeight = (point.critical_count / maxErrors) * chartHeight;

              return (
                <g key={index}>
                  {/* Total errors bar */}
                  <rect
                    x={`${x}%`}
                    y={chartHeight - totalHeight}
                    width={`${barWidth}%`}
                    height={totalHeight}
                    className="bar-total"
                    data-tooltip={`${new Date(point.hour).toLocaleTimeString()}: ${point.error_count} errors`}
                  />
                  
                  {/* Critical errors overlay */}
                  {point.critical_count > 0 && (
                    <rect
                      x={`${x}%`}
                      y={chartHeight - criticalHeight}
                      width={`${barWidth}%`}
                      height={criticalHeight}
                      className="bar-critical"
                      data-tooltip={`${point.critical_count} critical`}
                    />
                  )}

                  {/* X-axis label (every 4 hours) */}
                  {index % 4 === 0 && (
                    <text
                      x={`${x}%`}
                      y={chartHeight + 20}
                      className="axis-label-x"
                    >
                      {new Date(point.hour).getHours()}:00
                    </text>
                  )}
                </g>
              );
            })}
          </g>
        </svg>
      </div>
    </div>
  );
};
