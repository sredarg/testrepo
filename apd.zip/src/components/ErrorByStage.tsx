// src/components/ErrorByStage.tsx
import React from 'react';
import type { StageData } from '../types';

interface Props {
  data: StageData[];
}

export const ErrorByStage: React.FC<Props> = ({ data }) => {
  if (data.length === 0) {
    return (
      <div className="chart-container">
        <h2>Errors by Pipeline Stage</h2>
        <div className="no-data">No stage data available</div>
      </div>
    );
  }

  const totalErrors = data.reduce((sum, item) => sum + item.count, 0);
  const maxCount = Math.max(...data.map(d => d.count), 1);

  return (
    <div className="chart-container">
      <h2>Errors by Pipeline Stage</h2>
      
      <div className="stage-chart">
        {data.map((stage, index) => {
          const percentage = (stage.count / totalErrors) * 100;
          const barWidth = (stage.count / maxCount) * 100;

          return (
            <div key={index} className="stage-item">
              <div className="stage-info">
                <div className="stage-name">
                  {stage.pipeline_stage || 'Unknown'}
                </div>
                <div className="stage-type">{stage.error_type}</div>
              </div>
              
              <div className="stage-bar-container">
                <div 
                  className="stage-bar"
                  style={{ width: `${barWidth}%` }}
                >
                  <span className="bar-label">
                    {stage.count} ({percentage.toFixed(1)}%)
                  </span>
                </div>
              </div>

              {stage.critical_count > 0 && (
                <div className="critical-badge">
                  🚨 {stage.critical_count} critical
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="chart-footer">
        Total: {totalErrors} errors across {data.length} stage/type combinations
      </div>
    </div>
  );
};
