// src/components/Dashboard.tsx
import React, { useState, useEffect } from 'react';
import { ErrorSummary } from './ErrorSummary';
import { ServerTable } from './ServerTable';
import { ErrorTimeline } from './ErrorTimeline';
import { ErrorByStage } from './ErrorByStage';
import { RecentErrors } from './RecentErrors';
import { api } from '../services/api';
import type { 
  DashboardSummary, 
  ServerError, 
  TimelineData, 
  StageData,
  RecentError 
} from '../types';
import '../styles/Dashboard.css';

export const Dashboard: React.FC = () => {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [serverErrors, setServerErrors] = useState<ServerError[]>([]);
  const [timeline, setTimeline] = useState<TimelineData[]>([]);
  const [stageData, setStageData] = useState<StageData[]>([]);
  const [recentErrors, setRecentErrors] = useState<RecentError[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [summaryData, serverData, timelineData, stageDataRes, recentData] = 
        await Promise.all([
          api.getSummary(),
          api.getServerErrors(),
          api.getTimeline(),
          api.getErrorsByStage(),
          api.getRecentErrors()
        ]);

      setSummary(summaryData);
      setServerErrors(serverData);
      setTimeline(timelineData);
      setStageData(stageDataRes);
      setRecentErrors(recentData);
      setError(null);
    } catch (err) {
      setError('Failed to fetch dashboard data');
      console.error('Dashboard fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();

    // Auto-refresh every 30 seconds
    let interval: NodeJS.Timeout;
    if (autoRefresh) {
      interval = setInterval(fetchDashboardData, 30000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh]);

  if (loading && !summary) {
    return (
      <div className="dashboard-loading">
        <div className="spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-error">
        <h2>Error Loading Dashboard</h2>
        <p>{error}</p>
        <button onClick={fetchDashboardData}>Retry</button>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1>Atoll Pipeline Error Dashboard</h1>
        <div className="header-controls">
          <button 
            onClick={fetchDashboardData} 
            className="refresh-btn"
            disabled={loading}
          >
            🔄 Refresh
          </button>
          <label className="auto-refresh-toggle">
            <input 
              type="checkbox" 
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
            />
            Auto-refresh (30s)
          </label>
          <span className="last-update">
            Last updated: {new Date().toLocaleTimeString()}
          </span>
        </div>
      </header>

      {summary && <ErrorSummary data={summary} />}

      <div className="dashboard-grid">
        <div className="grid-item full-width">
          <ServerTable data={serverErrors} />
        </div>

        <div className="grid-item half-width">
          <ErrorTimeline data={timeline} />
        </div>

        <div className="grid-item half-width">
          <ErrorByStage data={stageData} />
        </div>

        <div className="grid-item full-width">
          <RecentErrors data={recentErrors} />
        </div>
      </div>
    </div>
  );
};
