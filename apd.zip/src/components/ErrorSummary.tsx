// src/components/ErrorSummary.tsx
import React from 'react';
import type { DashboardSummary } from '../types';

interface Props {
  data: DashboardSummary;
}

export const ErrorSummary: React.FC<Props> = ({ data }) => {
  return (
    <div className="summary-cards">
      <div className="summary-card">
        <div className="card-icon">📊</div>
        <div className="card-content">
          <h3>Total Errors</h3>
          <p className="card-value">{data.total_errors}</p>
          <span className="card-label">Last 24 hours</span>
        </div>
      </div>

      <div className="summary-card">
        <div className="card-icon">🖥️</div>
        <div className="card-content">
          <h3>Affected Servers</h3>
          <p className="card-value">{data.affected_servers}</p>
          <span className="card-label">Out of ~300 total</span>
        </div>
      </div>

      <div className="summary-card warning">
        <div className="card-icon">⚠️</div>
        <div className="card-content">
          <h3>Active Errors</h3>
          <p className="card-value">{data.active_errors}</p>
          <span className="card-label">Unresolved</span>
        </div>
      </div>

      <div className="summary-card critical">
        <div className="card-icon">🚨</div>
        <div className="card-content">
          <h3>Critical Errors</h3>
          <p className="card-value">{data.critical_errors}</p>
          <span className="card-label">Needs immediate attention</span>
        </div>
      </div>
    </div>
  );
};
