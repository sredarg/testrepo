// src/types/index.ts

export interface DashboardSummary {
  total_errors: number;
  affected_servers: number;
  active_errors: number;
  critical_errors: number;
}

export interface ServerError {
  instance_id: string;
  ipaddress: string;
  server_status: string;
  error_count: number;
  active_errors: number;
  last_error_time: string;
  has_critical_error: number;
}

export interface TimelineData {
  hour: string;
  error_count: number;
  critical_count: number;
}

export interface StageData {
  pipeline_stage: string;
  error_type: string;
  count: number;
  critical_count: number;
}

export interface RecentError {
  error_id: number;
  instance_id: string;
  ipaddress: string;
  error_timestamp: string;
  error_type: string;
  error_message: string;
  pipeline_stage: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  resolved: boolean;
}

export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
}
