// src/services/api.ts
import type { 
  DashboardSummary, 
  ServerError, 
  TimelineData, 
  StageData,
  RecentError,
  ApiResponse 
} from '../types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

class ApiService {
  private async fetchData<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.statusText}`);
    }

    const result: ApiResponse<T> = await response.json();
    
    if (!result.success) {
      throw new Error(result.message || 'API request failed');
    }

    return result.data;
  }

  async getSummary(): Promise<DashboardSummary> {
    return this.fetchData<DashboardSummary>('/summary');
  }

  async getServerErrors(): Promise<ServerError[]> {
    return this.fetchData<ServerError[]>('/servers');
  }

  async getTimeline(): Promise<TimelineData[]> {
    return this.fetchData<TimelineData[]>('/timeline');
  }

  async getErrorsByStage(): Promise<StageData[]> {
    return this.fetchData<StageData[]>('/stages');
  }

  async getRecentErrors(): Promise<RecentError[]> {
    return this.fetchData<RecentError[]>('/recent');
  }

  async resolveError(errorId: number): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/errors/${errorId}/resolve`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to resolve error');
    }
  }
}

export const api = new ApiService();
