# Atoll Pipeline Error Dashboard - Deployment Guide

## 📁 Project Structure

```
atoll-pipeline-dashboard/
├── public/
│   └── index.html                 # HTML template
├── src/
│   ├── components/
│   │   ├── Dashboard.tsx          # Main dashboard container
│   │   ├── ErrorSummary.tsx       # KPI summary cards
│   │   ├── ServerTable.tsx        # Sortable/filterable server error table
│   │   ├── ErrorTimeline.tsx      # 24-hour error timeline chart
│   │   ├── ErrorByStage.tsx       # Pipeline stage breakdown
│   │   └── RecentErrors.tsx       # Recent errors log with expand/collapse
│   ├── services/
│   │   └── api.ts                 # API service layer
│   ├── styles/
│   │   ├── index.css             # Global styles
│   │   ├── App.css               # Component-specific styles
│   │   └── Dashboard.css         # Dashboard layout styles
│   ├── types/
│   │   └── index.ts              # TypeScript type definitions
│   ├── App.tsx                   # Root application component
│   └── index.tsx                 # Application entry point
├── server/
│   ├── index.js                  # Express API server
│   ├── package.json              # Server dependencies
│   └── .env.example              # Server environment variables template
├── package.json                  # Frontend dependencies
├── tsconfig.json                 # TypeScript configuration
├── .env.example                  # Frontend environment variables template
└── database_schema.sql           # PostgreSQL schema and queries
```

## 🚀 Technology Stack

### Frontend
- **Framework**: React 18 with TypeScript
- **Styling**: Pure CSS (no external UI libraries)
- **State Management**: React Hooks (useState, useEffect, useMemo)
- **HTTP Client**: Native Fetch API
- **Build Tool**: React Scripts (Create React App)

### Backend
- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: PostgreSQL
- **Database Driver**: node-postgres (pg)

### Why This Stack?
- **React + TypeScript**: Type safety, component reusability, excellent developer experience
- **Express.js**: Lightweight, fast, and easy to deploy
- **PostgreSQL**: Already in use for radio.aws_instances table
- **No external charting libraries**: Lightweight, faster load times, full customization

## 📋 Prerequisites

Before deployment, ensure you have:

1. **Node.js** (v16 or higher)
2. **npm** or **yarn** package manager
3. **PostgreSQL** database (already set up with radio.aws_instances table)
4. **Git** (optional, for version control)

## 🔧 Setup Instructions

### Step 1: Database Setup

1. Connect to your PostgreSQL database:
```bash
psql -h your-host -U your-user -d your-database
```

2. Run the schema creation script:
```bash
psql -h your-host -U your-user -d your-database -f database_schema.sql
```

This will:
- Create the `radio.pipeline_errors` table
- Set up foreign key relationship with `radio.aws_instances`
- Create indexes for optimal query performance
- Add sample data (optional - you can comment out)

### Step 2: Backend Setup

1. Navigate to the server directory:
```bash
cd server
```

2. Install dependencies:
```bash
npm install
```

3. Create environment file:
```bash
cp .env.example .env
```

4. Edit `.env` with your database credentials:
```env
PORT=3001
DB_HOST=your-postgres-host
DB_PORT=5432
DB_NAME=your_database_name
DB_USER=your_database_user
DB_PASSWORD=your_database_password
```

5. Test the server:
```bash
npm start
```

The server should start on `http://localhost:3001`

Check health endpoint: `http://localhost:3001/health`

### Step 3: Frontend Setup

1. Navigate to the project root:
```bash
cd ..
```

2. Install dependencies:
```bash
npm install
```

3. Create environment file:
```bash
cp .env.example .env
```

4. Edit `.env` to point to your API:
```env
REACT_APP_API_URL=http://localhost:3001/api
```

5. Start the development server:
```bash
npm start
```

The dashboard should open at `http://localhost:3000`

## 🏗️ Production Build

### Building the Frontend

1. Create production build:
```bash
npm run build
```

This creates an optimized build in the `build/` directory.

2. The build folder contains:
```
build/
├── static/
│   ├── css/
│   ├── js/
│   └── media/
├── index.html
└── asset-manifest.json
```

### Deployment Options

#### Option 1: Deploy to Windows Server (IIS)

1. **Install IIS** with URL Rewrite module

2. **Build the frontend**:
```bash
npm run build
```

3. **Copy build files** to IIS wwwroot:
```
C:\inetpub\wwwroot\dashboard\
```

4. **Install Node.js** on the Windows server

5. **Copy server folder** to:
```
C:\atoll-dashboard-server\
```

6. **Install PM2** (process manager):
```bash
npm install -g pm2
npm install -g pm2-windows-startup
pm2-startup install
```

7. **Start the API server**:
```bash
cd C:\atoll-dashboard-server
pm2 start index.js --name "atoll-api"
pm2 save
```

8. **Configure IIS**:
   - Create a new site pointing to `C:\inetpub\wwwroot\dashboard`
   - Add URL Rewrite rule for React Router (all requests → index.html)
   - Add reverse proxy for `/api` → `http://localhost:3001/api`

9. **web.config** for IIS (place in build folder):
```xml
<?xml version="1.0"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="API Proxy" stopProcessing="true">
          <match url="^api/(.*)" />
          <action type="Rewrite" url="http://localhost:3001/api/{R:1}" />
        </rule>
        <rule name="React Routes" stopProcessing="true">
          <match url=".*" />
          <conditions logicalGrouping="MatchAll">
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="/" />
        </rule>
      </rules>
    </rewrite>
  </system.webServer>
</configuration>
```

#### Option 2: Deploy to Linux Server (Nginx)

1. **Build the frontend**:
```bash
npm run build
```

2. **Copy files to server**:
```bash
scp -r build/* user@server:/var/www/dashboard/
scp -r server user@server:/opt/atoll-dashboard-api/
```

3. **Install dependencies on server**:
```bash
ssh user@server
cd /opt/atoll-dashboard-api
npm install --production
```

4. **Set up PM2**:
```bash
npm install -g pm2
pm2 start index.js --name atoll-api
pm2 startup
pm2 save
```

5. **Configure Nginx** (`/etc/nginx/sites-available/dashboard`):
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    # Frontend
    location / {
        root /var/www/dashboard;
        index index.html;
        try_files $uri $uri/ /index.html;
    }
    
    # API Proxy
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

6. **Enable and restart Nginx**:
```bash
sudo ln -s /etc/nginx/sites-available/dashboard /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### Option 3: Docker Deployment

Create `Dockerfile` for frontend:
```dockerfile
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Create `Dockerfile` for backend:
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY server/package*.json ./
RUN npm install --production
COPY server/ .
EXPOSE 3001
CMD ["node", "index.js"]
```

Create `docker-compose.yml`:
```yaml
version: '3.8'
services:
  api:
    build:
      context: .
      dockerfile: Dockerfile.api
    ports:
      - "3001:3001"
    environment:
      - DB_HOST=${DB_HOST}
      - DB_PORT=${DB_PORT}
      - DB_NAME=${DB_NAME}
      - DB_USER=${DB_USER}
      - DB_PASSWORD=${DB_PASSWORD}
    restart: unless-stopped
    
  frontend:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "80:80"
    depends_on:
      - api
    restart: unless-stopped
```

Deploy with:
```bash
docker-compose up -d
```

## 📊 How to Populate Error Data

### Method 1: Manual Insert (Testing)
```sql
INSERT INTO radio.pipeline_errors 
    (instance_id, error_type, error_message, pipeline_stage, severity)
VALUES 
    ('i-0123456789abcdef0', 'TimeoutError', 'Pipeline execution timeout', 'Coverage Generation', 'HIGH');
```

### Method 2: From Application Logs
Parse your Atoll application logs and insert errors programmatically:

```python
# Python example
import psycopg2

conn = psycopg2.connect(
    host="your-host",
    database="your-db",
    user="your-user",
    password="your-password"
)

def log_error(instance_id, error_type, message, stage, severity):
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO radio.pipeline_errors 
        (instance_id, error_type, error_message, pipeline_stage, severity)
        VALUES (%s, %s, %s, %s, %s)
    """, (instance_id, error_type, message, stage, severity))
    conn.commit()
    cur.close()
```

### Method 3: Using the API Endpoint
```bash
curl -X POST http://localhost:3001/api/errors \
  -H "Content-Type: application/json" \
  -d '{
    "instance_id": "i-abc123",
    "error_type": "ConfigError",
    "error_message": "Missing required parameter",
    "pipeline_stage": "Initialization",
    "severity": "MEDIUM"
  }'
```

### Method 4: Windows PowerShell Script
Create a script that monitors Atoll logs and posts to the API:

```powershell
# monitor-atoll-errors.ps1
$apiUrl = "http://localhost:3001/api/errors"
$logPath = "C:\Atoll\Logs\pipeline.log"

Get-Content $logPath -Wait -Tail 0 | ForEach-Object {
    if ($_ -match "ERROR") {
        $body = @{
            instance_id = $env:COMPUTERNAME
            error_type = "RuntimeError"
            error_message = $_
            pipeline_stage = "Execution"
            severity = "HIGH"
        } | ConvertTo-Json

        Invoke-RestMethod -Uri $apiUrl -Method Post -Body $body -ContentType "application/json"
    }
}
```

## 🔄 Maintenance

### Updating the Dashboard

1. Pull latest changes:
```bash
git pull origin main
```

2. Rebuild frontend:
```bash
npm run build
```

3. Restart API server:
```bash
pm2 restart atoll-api
```

### Database Cleanup

To prevent the errors table from growing too large, set up a cleanup job:

```sql
-- Delete errors older than 30 days
DELETE FROM radio.pipeline_errors 
WHERE error_timestamp < NOW() - INTERVAL '30 days';
```

Schedule this with cron (Linux) or Task Scheduler (Windows).

### Monitoring API Health

Set up a health check monitor:
```bash
curl http://localhost:3001/health
```

Expected response:
```json
{
  "success": true,
  "message": "API is running",
  "timestamp": "2024-02-13T10:30:00.000Z"
}
```

## 🐛 Troubleshooting

### Issue: Dashboard shows "Failed to fetch"
- Check if API server is running: `curl http://localhost:3001/health`
- Verify CORS settings in server/index.js
- Check `.env` file has correct `REACT_APP_API_URL`

### Issue: Database connection errors
- Verify PostgreSQL is running
- Check credentials in `server/.env`
- Ensure radio schema exists and user has permissions

### Issue: Blank dashboard
- Check browser console for errors
- Verify API endpoints return data
- Test queries directly in PostgreSQL

### Issue: Slow performance
- Add more database indexes
- Enable connection pooling (already configured)
- Consider caching frequently accessed data

## 📈 Next Steps / Enhancements

1. **Authentication**: Add user login and role-based access
2. **Alerts**: Email/Slack notifications for critical errors
3. **Export**: Download error reports as CSV/PDF
4. **Filtering**: Date range picker, severity filters
5. **Metrics**: Add performance metrics (response time, throughput)
6. **Mobile**: Enhance responsive design for mobile devices
7. **Real-time**: WebSocket support for live updates

## 📞 Support

For issues or questions:
1. Check this README
2. Review error logs in browser console and server logs
3. Verify database schema matches expected structure
4. Test individual API endpoints with curl/Postman
