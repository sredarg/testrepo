#!/bin/bash
# =============================================================================
# deploy.sh  —  Atoll Pipeline Dashboard — Linux Production Deployment
#               Using Apache HTTPD
# =============================================================================
# Usage:
#   chmod +x deploy.sh
#   sudo ./deploy.sh
# =============================================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[ OK ]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERR ]${NC} $1"; exit 1; }

# ══ EDIT THESE BEFORE RUNNING ══════════════════════════════════════════════
SERVER_NAME="your-server-ip-or-domain.com"
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="your_database"
DB_USER="atoll_user"
DB_PASSWORD="CHANGE_ME_STRONG"
APP_DIR="/opt/atoll-dashboard"
WEB_DIR="/var/www/atoll-dashboard"
LOG_DIR="/var/log/atoll-dashboard"
APP_USER="atoll"
# ═══════════════════════════════════════════════════════════════════════════

echo ""
echo "Atoll Pipeline Dashboard — Production Deployment (Apache HTTPD)"
echo "================================================================"
echo ""

[[ $EUID -ne 0 ]] && error "Run as root: sudo ./deploy.sh"

# Detect distro
if command -v apt-get &>/dev/null; then
  DISTRO="debian"; HTTPD_SERVICE="apache2"; HTTPD_PKG="apache2"
  HTTPD_CONF_DIR="/etc/apache2/sites-available"
  HTTPD_LOG_DIR="/var/log/apache2"; APACHE_USER="www-data"
  apt-get update -qq
elif command -v yum &>/dev/null || command -v dnf &>/dev/null; then
  DISTRO="rhel"; HTTPD_SERVICE="httpd"; HTTPD_PKG="httpd"
  HTTPD_CONF_DIR="/etc/httpd/conf.d"
  HTTPD_LOG_DIR="/var/log/httpd"; APACHE_USER="apache"
else
  error "Unsupported distro. Use Ubuntu/Debian or CentOS/RHEL."
fi
info "Distro: $DISTRO"

# STEP 1 — Node.js
info "Step 1/9 — Node.js 18..."
if command -v node &>/dev/null && [[ $(node -v | cut -d. -f1 | tr -d v) -ge 18 ]]; then
  success "Node.js $(node -v) ready"
else
  curl -fsSL https://deb.nodesource.com/setup_18.x | bash - &>/dev/null 2>&1 || \
  curl -fsSL https://rpm.nodesource.com/setup_18.x | bash - &>/dev/null 2>&1
  apt-get install -y -q nodejs 2>/dev/null || yum install -y nodejs 2>/dev/null || dnf install -y nodejs 2>/dev/null
  success "Node.js $(node -v) installed"
fi

# STEP 2 — Apache HTTPD
info "Step 2/9 — Apache HTTPD..."
if ! systemctl is-active --quiet "$HTTPD_SERVICE" 2>/dev/null; then
  apt-get install -y -q "$HTTPD_PKG" 2>/dev/null || yum install -y "$HTTPD_PKG" 2>/dev/null || dnf install -y "$HTTPD_PKG" 2>/dev/null
  systemctl enable "$HTTPD_SERVICE"
  systemctl start  "$HTTPD_SERVICE"
fi
if [[ "$DISTRO" == "debian" ]]; then
  a2enmod proxy proxy_http rewrite headers deflate expires &>/dev/null
fi
success "Apache HTTPD ready"

# STEP 3 — PM2
info "Step 3/9 — PM2..."
command -v pm2 &>/dev/null || npm install -g pm2 --silent
success "PM2 ready"

# STEP 4 — Directories and user
info "Step 4/9 — System user and directories..."
id "$APP_USER" &>/dev/null || useradd --system --no-create-home --shell /usr/sbin/nologin "$APP_USER"
mkdir -p "$APP_DIR" "$WEB_DIR" "$LOG_DIR"
chown "$APP_USER:$APP_USER" "$APP_DIR" "$LOG_DIR"
success "Directories ready"

# STEP 5 — Deploy files
info "Step 5/9 — Deploying files..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cp -r "$PROJECT_ROOT/server"       "$APP_DIR/"
cp -r "$PROJECT_ROOT/src"          "$APP_DIR/"
cp -r "$PROJECT_ROOT/public"       "$APP_DIR/"
cp    "$PROJECT_ROOT/package.json" "$APP_DIR/"
cp    "$PROJECT_ROOT/tsconfig.json" "$APP_DIR/"

cat > "$APP_DIR/server/.env" << ENVEOF
NODE_ENV=production
PORT=3001
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
ALLOWED_ORIGINS=http://$SERVER_NAME
ENVEOF
chmod 600 "$APP_DIR/server/.env"
chown "$APP_USER:$APP_USER" "$APP_DIR/server/.env"

cd "$APP_DIR/server" && npm install --production --silent
chown -R "$APP_USER:$APP_USER" "$APP_DIR"

info "  Building React frontend (~60 sec)..."
cd "$APP_DIR" && npm install --silent
REACT_APP_API_URL=/api npm run build

cp -r "$APP_DIR/build/." "$WEB_DIR/"
cp "$SCRIPT_DIR/httpd/.htaccess" "$WEB_DIR/.htaccess"
chown -R "$APACHE_USER:$APACHE_USER" "$WEB_DIR"
chmod -R 755 "$WEB_DIR"
success "Files deployed"

# STEP 6 — Apache VirtualHost config
info "Step 6/9 — Apache VirtualHost config..."
cat > "$HTTPD_CONF_DIR/atoll-dashboard.conf" << APACHECONF
<VirtualHost *:80>
    ServerName   $SERVER_NAME
    DocumentRoot $WEB_DIR

    ErrorLog  $HTTPD_LOG_DIR/atoll-dashboard-error.log
    CustomLog $HTTPD_LOG_DIR/atoll-dashboard-access.log combined

    <Directory $WEB_DIR>
        Options -Indexes -FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    <IfModule mod_rewrite.c>
        RewriteEngine On
        RewriteBase /
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteCond %{REQUEST_URI} !^/api
        RewriteCond %{REQUEST_URI} !^/health
        RewriteRule ^ /index.html [L]
    </IfModule>

    <IfModule mod_proxy.c>
        ProxyRequests     Off
        ProxyPreserveHost On
        ProxyPass        /api    http://127.0.0.1:3001/api
        ProxyPassReverse /api    http://127.0.0.1:3001/api
        ProxyPass        /health http://127.0.0.1:3001/health
        ProxyPassReverse /health http://127.0.0.1:3001/health
        RequestHeader set X-Real-IP       "%{REMOTE_ADDR}e"
        RequestHeader set X-Forwarded-For "%{REMOTE_ADDR}e"
    </IfModule>

    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json
    </IfModule>

    <IfModule mod_headers.c>
        Header always set X-Frame-Options        "SAMEORIGIN"
        Header always set X-Content-Type-Options "nosniff"
        Header always set X-XSS-Protection       "1; mode=block"
        Header unset Server
    </IfModule>

    <FilesMatch "^\\.">
        Require all denied
    </FilesMatch>
</VirtualHost>
APACHECONF

[[ "$DISTRO" == "debian" ]] && a2ensite atoll-dashboard &>/dev/null && a2dissite 000-default &>/dev/null || true
apachectl configtest 2>&1 | grep -E "Syntax OK|Error"
systemctl reload "$HTTPD_SERVICE"
success "Apache configured"

# STEP 7 — Database
info "Step 7/9 — Database setup..."
if command -v psql &>/dev/null; then
  PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
    -f "$SCRIPT_DIR/db/db_setup_production.sql" &>/dev/null \
    && success "Database schema applied" \
    || warn "DB setup had warnings — verify manually"
else
  warn "psql not on this machine — run db/db_setup_production.sql manually"
fi

# STEP 8 — PM2
info "Step 8/9 — PM2 process manager..."
cp "$SCRIPT_DIR/pm2/ecosystem.config.js" "$APP_DIR/"
sed -i "s|/opt/atoll-dashboard|$APP_DIR|g" "$APP_DIR/ecosystem.config.js"
su -s /bin/bash "$APP_USER" -c "cd $APP_DIR && pm2 start ecosystem.config.js" 2>/dev/null
su -s /bin/bash "$APP_USER" -c "pm2 save" 2>/dev/null
PM2_CMD=$(env PATH=$PATH:/usr/bin pm2 startup systemd -u "$APP_USER" --hp "/home/$APP_USER" 2>/dev/null | grep "sudo" | tail -1)
[[ -n "$PM2_CMD" ]] && eval "$PM2_CMD" &>/dev/null || true
success "API server running"

# STEP 9 — Firewall
info "Step 9/9 — Firewall..."
if command -v ufw &>/dev/null; then
  ufw allow ssh &>/dev/null; ufw allow 80/tcp &>/dev/null
  ufw deny 3001 &>/dev/null; ufw --force enable &>/dev/null
  success "UFW: port 80 open, 3001 blocked"
elif command -v firewall-cmd &>/dev/null; then
  firewall-cmd --permanent --add-service=http &>/dev/null
  firewall-cmd --permanent --add-service=ssh  &>/dev/null
  firewall-cmd --reload &>/dev/null
  success "firewalld: port 80 open"
else
  warn "No firewall tool found — open port 80 manually"
fi

echo ""
echo "================================================================"
echo " Deployment Complete!"
echo "================================================================"
echo ""
echo " Dashboard : http://$SERVER_NAME"
echo " Health    : http://$SERVER_NAME/health"
echo " API       : http://$SERVER_NAME/api/summary"
echo ""
echo " Commands:"
echo "   pm2 status"
echo "   pm2 logs atoll-api"
echo "   sudo systemctl status $HTTPD_SERVICE"
echo "   ./deploy/healthcheck.sh"
echo ""
